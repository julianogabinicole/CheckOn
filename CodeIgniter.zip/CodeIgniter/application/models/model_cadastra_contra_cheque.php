<?php


class Model_cadastra_contra_cheque extends CI_Model {
   
     function __construct() {
        parent::__construct();
    }

  public function retorna_dados_contra_cheque()
{    
       
     $this->db->order_by('proventos', 'desc');
     $consulta = $this->db->get('tbl_descricao');
 
      return $consulta;
}

 public function retorna_dados_usuario_contra_cheque()
{
     
       $this->db->order_by('id', 'desc'  );  
      $consulta = $this->db->get('tbl_cadastro_usuarios');
       return $consulta;
}
 public function verifica_cadastro($periodo,$nome_func)
 {
        $this->db->where("periodo", $periodo);
        $this->db->where("nome_func", $nome_func);
        $usuario = $this->db->get("tbl_contra_cheque")->row_array();
        return $usuario;
 
   }
public function get_result(){   
    //For selecting one or more columns
 //echo $_SESSION["nome_func_cargo"] ;
$this->db->select('*');    
$this->db->from('tbl_cargo');
$this->db->join('tbl_cadastro_usuarios', 'tbl_cargo.cargo_func = tbl_cadastro_usuarios.cargo', 'inner');
$this->db->where('matricula', $_SESSION["nome_func_cargo"]); 
$this->db->where('matricula_empresa', $_SESSION["matricula_logada"]); 
 //return $consulta;
$query = $this->db->get();
 return $query;
}
public function get_dados_salario(){   
    //For selecting one or more columns
 //echo $_SESSION["nome_func_cargo"] ;
$this->db->select('*');    
$this->db->from('tbl_cadastro_usuarios');
$this->db->join('tbl_cargo', 'tbl_cargo.cargo_func = tbl_cadastro_usuarios.cargo', 'inner');

$this->db->where('matricula',$_SESSION["matricula_logada"]); 
//$this->db->where('matricula_empresa', $_SESSION["matricula_logada"]); 
 //return $consulta;
$query = $this->db->get();
 return $query;
}
    public function get_contra_cheque(){   
        
        
$this->db->select('vinculacao_func');    
$this->db->from('tbl_cadastro_usuarios');
$this->db->where('matricula', $_SESSION["matricula_logada"]);
$query = $this->db->get();
 return $query;
 }
    public function get_dados_contra_cheque(){   
        
   $this->db->select('*');    
$this->db->from('tbl_cadastro_usuarios');
$this->db->where('matricula',$_SESSION["matricula_logada"]);
$query = $this->db->get();
 return $query;

    }
    public function get_vinc_func(){  
    $this->db->select('*');    
$this->db->from('tbl_cadastro_empresas');
$this->db->where('matricula',$_SESSION["dados_func"]);
$query = $this->db->get();
 return $query;
 
    }
     public function get_soma_contra_cheque(){  
         //echo  $_SESSION["periodo"];
       
   $this->db->select_sum('desconto','desconto');
   $this->db->select_sum('provento','provento');
   $this->db->select_sum('inss','inss');
   $this->db->select_sum('passagem','passagem');
   $this->db->from('tbl_contra_cheque');
  //  $this->db->select('periodo'); 
   $this->db->where("periodo", $_SESSION["periodo"]);
   $this->db->where("nome_func",$_SESSION["matricula_logada"]);
   
   $query = $this->db->get();
 return $query;
     }
}
