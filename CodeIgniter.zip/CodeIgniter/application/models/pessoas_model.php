<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
   // session_start();
class Pessoas_model extends CI_Model {
 
    function __construct() {
        parent::__construct();
    }
 
    function cadastrar($data) {
         //$codificada = base64_encode($data_senha);
         //$original = base64_decode($codificada);
        return $this->db->insert('tbl_cadastro_login', $data);
    }
     function atualizar_senha($data,$nome) {
       //  echo $data;
    
    $this->db->where('nome', $nome);
    return $this->db->update('tbl_cadastro_login' ,$data);
       
    }
 
  function ValidarUsuarioNome($nome){ 
      //   Consulta Mysql para buscar na tabela Usuario aqueles usuarios que coincidam com o mail e password inscritos na tela de login
      $senha = $_POST['senha'];
      $codificada  = md5($senha);
      
      $query = $this->db->where('nome',$nome);  
       $query = $this->db->where('senha',$codificada);  //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
       $query = $this->db->get('tbl_cadastro_login');
      return $query->row();    //   Retornamos ao controlador a fila que coincide com a busca. (FALSE no caso de não existirem coincidencias)
   }
   function ValidarUsuarioEmail($email){         //   Consulta Mysql para buscar na tabela Usuario aqueles usuarios que coincidam com o mail e password inscritos na tela de login
       $query = $this->db->where('email',$email);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
      
       
      $query = $this->db->get('tbl_cadastro_login');
      return $query->row();    //   Retornamos ao controlador a fila que coincide com a busca. (FALSE no caso de não existirem coincidencias)
  
   }
       function ValidarUsuarioSenha($senha){         //   Consulta Mysql para buscar na tabela Usuario aqueles usuarios que coincidam com o mail e password inscritos na tela de login
       
            $senha = $_POST['senha'];
           $codificada  = md5($senha);
          //echo $senha;
           $query = $this->db->where('senha',$codificada);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
      
       
      $query = $this->db->get('tbl_cadastro_login');
      return $query->row(); 
      
       }
   function ValidarMatriculaFuncionario($nome){  
       $query = $this->db->where('matricula',$nome);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
      $query = $this->db->get('tbl_cadastro_usuarios');
      return $query->row();  
   }
     function ValidarMatriculaEmpresa($nome){  
       $query = $this->db->where('matricula',$nome);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
      $query = $this->db->get('tbl_cadastro_empresas');
      return $query->row();  
   }
    function alterar_senha_usuario($data) {
     $matricula= $_SESSION["matricula_logada"];
    //  echo   $nova_senha;
    $this->db->where('nome', $matricula);
      return $this->db->update('tbl_cadastro_login' ,$data);
        }
        
        function retorna_dados()
{//$matricula = $_SESSION['matricula_enviada'];
       $matricula_gera_relatorio= $_SESSION["matricula_logada"];
       echo $matricula_gera_relatorio;
   $query = $this->db->where('nome', $matricula_gera_relatorio );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
       $query = $this->db->get('tbl_cadastro_login');
       return $query->row();

}
 function retorna_mostra_nome()
{//$matricula = $_SESSION['matricula_enviada'];
       $matricula_mostra_nome= $_SESSION["matricula_logada"];
      // echo $matricula_gera_relatorio;
   $query = $this->db->where('matricula',  $matricula_mostra_nome );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
      $query = $this->db->get('tbl_cadastro_empresas');
       return $query->row();
     ////////////////////////////
   $query = $this->db->where('matricula',  $matricula_mostra_nome );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
      $query = $this->db->get('tbl_cadastro_usuarios');
       return $query->row();

}

public function get_mostra_nome(){   
    //For selecting one or more columns
 //echo $_SESSION["nome_func_cargo"] ;
$this->db->select('*');    
$this->db->from('tbl_cadastro_empresas');
$this->db->join('tbl_cadastro_usuarios', 'tbl_cadastro_empresas.matricula = tbl_cadastro_usuarios.matricula', 'inner');
$this->db->where('matricula', $_SESSION["matricula_logada"]); 
//$this->db->where('matricula', $_SESSION["matricula_logada"]); 
 //return $consulta;
$query = $this->db->get();
 return $query;
}

    } 
