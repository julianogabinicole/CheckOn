 

<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cadastra_empresa_model extends CI_Model {
 
    function __construct() {
        parent::__construct();
    }
    
    function cadastrar($data) {
        
      //  echo $razao_social;
        return $this->db->insert('tbl_cadastro_empresas', $data);
    }
    
    public function retorna_alteracao()
{
        
     $this->db->order_by('id', 'desc');
     $consulta = $this->db->get('tbl_cadastro_empresas');
 
return $consulta;
}
    public function retorna_usuario()
{
        $id_altera= $_SESSION["id_empresa"];
       //echo $matricula= $_POST['matricula'];
       $query = $this->db->where('id', $id_altera );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
       $query = $this->db->get('tbl_cadastro_empresas');
       return $query->row();
}

 public function ultimo_campo_id()
{
  
 $this->db->insert_id('id');
$consulta = $this->db->get('tbl_cadastro_empresas');
$consulta++;
return $consulta ;
}
 function alterar_cadastro_empresa($data) {
       //  echo $data;
       $altera_empresa=$_SESSION["id_empresa"];
    $this->db->where('id',   $altera_empresa);
      return $this->db->update('tbl_cadastro_empresas' ,$data);
        }
  function consulta_dados_usuario(){ 
       $matricula = $_SESSION['matricula_enviada']; //variavel session pega da view tela_altera_usuario.php
            //   Consulta Mysql para buscar na tabela Usuario aqueles usuarios que coincidam com o mail e password inscritos na tela de login
       $query = $this->db->where('matricula',$matricula);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
       $query = $this->db->get('tbl_cadastro_empresas');
      return $query->row();    //   Retornamos ao controlador a fila que coincide com a busca. (FALSE no caso de não existirem coincidencias)
   }
  function excluir_dado($id_exclui_empresa){
   
         $this->db->where('id', $id_exclui_empresa);
      return $this->db->delete('tbl_cadastro_empresas');
    } 
      public function retorna_dados_empresas()
{
        
  $this->db->order_by('id', 'desc');
     $consulta = $this->db->get('tbl_cadastro_empresas');
 
return $consulta;
}
}
    