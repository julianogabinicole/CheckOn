 

<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class cadastra_usuario_model extends CI_Model {
 
    function __construct() {
        parent::__construct();
    }
    
    function cadastrar($data) {
       // echo $data;
        
        return $this->db->insert('tbl_cadastro_usuarios', $data);
    }
    
    public function retorna_alteracao()
{
        
     $this->db->order_by('id', 'desc');
     $consulta = $this->db->get('tbl_cadastro_usuarios');
 
return $consulta;
}
    public function retorna_usuario()
{//$matricula = $_SESSION['matricula_enviada'];
       $id_func = $_SESSION["id_consulta"];
     
       $query = $this->db->where('id', $id_func  );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
      $query = $this->db->get('tbl_cadastro_usuarios');
    return $query;

     
       
}
 public function ultimo_campo_id()
{
  
 $this->db->insert_id('id');
$consulta = $this->db->get('tbl_cadastro_usuarios');
$consulta++;
return $consulta ;
}
 function alterar_cadastro_usuario($data) {
      $id_consulta= $_SESSION["id_consulta"];
      $this->db->where('id', $id_consulta);
      return $this->db->update('tbl_cadastro_usuarios' ,$data);
        }
  function consulta_dados_usuario(){ 
    
       $query = $this->db->where('matricula',$matricula);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
       $query = $this->db->get('tbl_cadastro_usuarios');
       return $query->row();    //   Retornamos ao controlador a fila que coincide com a busca. (FALSE no caso de não existirem coincidencias)
   }
   
    function consulta_dados_cargo(){ 
     
 $this->db->select('*');    
$this->db->from('tbl_cadastro_empresas');
$this->db->join('tbl_cargo', 'tbl_cargo.matricula_empresa = tbl_cadastro_empresas.matricula', 'inner');
//$this->db->where('matricula', $_SESSION["nome_func_cargo"]); 
$this->db->where('matricula', $_SESSION["matricula_logada"]); 
 //return $consulta;
$query = $this->db->get();
 return $query;
    }
  function excluir_dado($id_remover){

      $this->db->where('id', $id_remover);
      return $this->db->delete('tbl_cadastro_usuarios');
    } 
     function excluir_cadastro($id_remover_cadastro){

      $this->db->where('nome', $id_remover_cadastro);
      return $this->db->delete('tbl_cadastro_login');
    } 
}
    