 

<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cadastra_cargo_model extends CI_Model {
 
    function __construct() {
        parent::__construct();
    }
    
    function cadastrar($data) {
       // echo $data;
        
        return $this->db->insert('tbl_cargo', $data);
    }
    
    public function retorna_alteracao()
{
        
     $this->db->order_by('id', 'desc');
     $consulta = $this->db->get('tbl_cadastro_usuarios');
 
return $consulta;
}
    public function retorna_cargo()
{//$matricula = $_SESSION['matricula_enviada'];
       $id_cargo = $_SESSION["id_consulta_cargo"];
     
       $query = $this->db->where('id_cargo', $id_cargo  );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
       $query = $this->db->get('tbl_cargo');
       return $query->row();
}
 public function ultimo_campo_id()
{
  
 $this->db->insert_id('id');
$consulta = $this->db->get('tbl_cadastro_usuarios');
$consulta++;
return $consulta ;
}
 function alterar_cargo($data) {
      $id_consulta= $_SESSION["id_consulta_cargo"];
      $this->db->where('id_cargo', $id_consulta);
      return $this->db->update('tbl_cargo' ,$data);
        }
  function consulta_dados_usuario(){ 
    
       $query = $this->db->where('matricula',$matricula);   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
       $query = $this->db->get('tbl_cadastro_usuarios');
      return $query->row();    //   Retornamos ao controlador a fila que coincide com a busca. (FALSE no caso de não existirem coincidencias)
   }
   
    function consulta_dados_cargo(){ 
     
       $matricula = $_SESSION["matricula_logada"];  
     
       $query = $this->db->where('matricula_empresa',$matricula);   
     $consulta = $this->db->get('tbl_cargo');
 
return $consulta;
}   

  function excluir_dado($id_remover_cargo){

      $this->db->where('id_cargo', $id_remover_cargo);
      return $this->db->delete('tbl_cargo');
    } 
}
    