<?php

class consultar_model extends CI_Model {
 
    function __construct() {
        parent::__construct();
    }

      public function retorna_consulta_nome()
{
     $this->db->order_by('id', 'asc');
     $consulta = $this->db->get('tbl_cadastro_usuarios');
 
return $consulta;
}  //put your code here
}
