<style type="text/css">
#box{

    border-radius: 10px;
    }
 
</style>
<!DOCTYPE html>
<html lang="pt-BR">
<head>

    <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario_senha.css">  
            
</head>
<body>
   
  
      <?php  //  $matricula=$this->session->userdata($matricula_login);?>
     
      <form class="form-signin" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/control_altera_senha/alt_senha/alterar">
                
            <div id="box" class="card card-container">
        
        
           
             Senha  <input type="password"  class="form-control" name="nova_senha"  placeholder="Insira sua nova senha" required autofocus>

               <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Alterar</button><br>

               </form>
     
</body>
</html>