
<script type="text/javascript">
function id( el ){
	return document.getElementById( el );
}
window.onload = function(){
	id('form').onsubmit = function(){
		return confirm( 'Tem certeza que deseja excluir cargo ?' );
	}
}
</script>
<style type="text/css">
#box{

    border-radius: 10px;
    }
 
</style>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

<html lang="pt-BR">
<head>

    <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario_tela_altera_senha.css">  
            
</head>
<body>

         
        <div id="box" class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
    <div class="table-responsive">
<table id="minhaTabela" class="display table" width="100%" >

        <thead>  
          <tr>  
            <th>Matrícula</th> 
            <th>Alterar Senha</th> 
         
          </tr>  
        </thead>  
        <tbody>
<?php //foreach($cargos as $dados){ ?>
          <tr> 
              <td><?php echo $_SESSION["matricula_logada"] ?></td> 
           
           
      <form method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/control_altera_senha/altera_senha/altera">
             <td>   <button class="btn btn-primary"  type="submit">Alterar</button></td>
                   
             </form>
        
       </tr>
            <?php
          
          //  } ?>
        </tbody>  
</table>
       </div>  
       </div>
</html>
