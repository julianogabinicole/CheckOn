<table id="minhaTabela" class="display table" width="100%" >

        <thead>  
          <tr>  
        
            <th>Desconto</th> 
         
            <th></th> 
            <th></th> 
        </tr>  
        </thead>  
    
        <tbody>
     
          <tr>  
            <td> <?php echo $desconto; ?> </td> 
                <td> <?php echo $provento; ?> </td> 
          
      
        </tr>