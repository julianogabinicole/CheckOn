

<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="http://localhost/CodeIgniter/js/script.js"></script>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<title></title>
	<meta name="generator" content="Bootply" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
         <link href="http://localhost/CodeIgniter/css/bootstrap.min.css" rel="stylesheet">   
         <link href="http://localhost/CodeIgniter/css/menu_vertical.css" rel="stylesheet">    
         <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/AVATAR.css">
         <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> 
<SCRIPT type="text/javascript">
    window.history.forward();
    function noBack() { window.history.forward(); }
</SCRIPT>
<SCRIPT type="text/javascript">
   function enviar_formulario(){
       document.formulario_href.submit()
   }
</SCRIPT>
</HEAD>
	</head>
	<body  onload="noBack();"
    onpageshow="if (event.persisted) noBack();" onunload="">
            <div>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
         <?php $texto=  $_SESSION["matricula_logada"] ;
    
         
         ?>
   <form class="form-signin" name="formulario_href" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/encaminha/emite" >
                  <input name="nome" type="hidden" id="id" value="<?= $_SESSION["matricula_logada"]; ?>" />
                   <input name="senha" type="hidden" id="id" value="<?= $_SESSION["senha_logada"]; ?>" />
             </form>
            <span  style="font-size: 25px;" text-align:center class="icon-bar"><font color="White"><?//= $mostra_nome ?></font></span>
   
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
           <li><a href="#"></a></li>
            <li><a href="#"></a></li>
            <li><a href="http://localhost/CodeIgniter/index.php/">Sair</a></li>
          </ul>
        
        </div>
  
</nav>
</div></div>
<div id='cssmenu'>

<ul>
    <li class='last'><a></a> 
        <li class='last'><a><span> </span> </a> 
             
             <li class='last'><a href="javascript:enviar_formulario()"><span>Home</span></a> 
      <?php if ( $texto[0]=="a" or $texto[0]=="A"){?>
    
    <li class='active has-sub'><a href='#'><span>Manter Empresa</span></a>
      <ul>
         <li class='last'><a href='http://localhost/CodeIgniter/index.php/empresas/encaminhaLink_empresa/tela_cadastro'><span>Inserir</span></a>
            <ul>
           
             </ul>
         </li>
         <li class='last'><a href='http://localhost/CodeIgniter/index.php/empresas/consultar/envia_consulta'><span>Consultar</span></a>
          
         </li>
         
      </ul>
       
   </li>
   <?php } ?>
       <?php if ($texto[0]=="E" or $texto[0]=="e" or $texto[0]=="a" or $texto[0]=="A"){?>


   <li class='active has-sub'><a href='#'><span>Manter Funcionário</span></a>
      <ul>
         <li class='last'><a href='http://localhost/CodeIgniter/index.php/funcionarios/encaminhaLink/tela_cadastro'><span>Inserir</span></a>
            <ul>
               <li><a href='#'><span>Inserir</span></a></li>
             </ul>
         </li>
         <li class='last'><a href='http://localhost/CodeIgniter/index.php/funcionarios/consultar/envia_consulta'><span>Consultar</span></a>
        
         </li>
         
      </ul>
       
   </li>

      <li class='active has-sub'><a href='#'><span>Manter Cargo</span></a>
      <ul>
         <li class='last'><a href='http://localhost/CodeIgniter/index.php/cargos/encaminhaLink_cargo/tela_cadastro_cargo'><span>Inserir</span></a>
            <ul>
               <li><a href='#'><span>Inserir</span></a></li>
             </ul>
         </li>
         <li class='last'><a href='http://localhost/CodeIgniter/index.php/cargos/consultar_cargo/envia_consulta'><span>Consultar</span></a>
        
         </li>
         
      </ul>
       
   </li>
  <li class='last'><a href='http://localhost/CodeIgniter/index.php/contra_cheque/cadastra_contra_cheque/envia_dados_select'><span>Cadastrar Contra Cheque</span></a> 
      
       <?php } ?>
  
       
  <?php if ($texto[0]=="F" or $texto[0]=="f" or $texto[0]=="a" or $texto[0]=="A"){?>
    

   <?php  } ?>
         <?php if ($texto[0]=="F" or $texto[0]=="f"){?>
    
   <li class='last'><a href='http://localhost/CodeIgniter/index.php/contra_cheque/control_gera_pdf_contra_cheque/tela_escolha_periodo'><span>Visualizar Contra Cheque</span></a> 
   <?php  } ?>
     <?php if ($texto[0]=="F" or $texto[0]=="f" or $texto[0]=="a" or $texto[0]=="A"or $texto[0]=="e"or $texto[0]=="E"){?>
   
  <li class='last'><a href='http://localhost/CodeIgniter/index.php/control_altera_senha/altera_senha/mudar_senha'><span>Alterar Senha</span></a> </li>
<?php } ?>

      </ul>
</div>

 
       </body>
</html>
