<!DOCTYPE html>
<script type="text/javascript" src="js/jquery-1.2.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.maskedinput-1.1.4.pack.js"/></script>
<html lang="pt-BR">
<head>
       <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario.css">  
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
        <script type="text/javascript" 
src="http://localhost/CodeIgniter/js/tratamento_campos.js"></script>
  <script type="text/javascript" src="http://localhost/CodeIgniter/js/trata_campo_cpf.js"></script>
   <script type="text/javascript" src="http://localhost/CodeIgniter/js/trata_cpf.js"></script>   
  <link rel="stylesheet" href="dist/css/bootstrap-select.css">      
</head>
<body>


 <form class="form-signin" id="form" name="form" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/funcionarios/cadastra_usuario/cadastrar">
    
        <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
            <tr><td>
              Usuário *  <input onKeypress="return somente_letras(event)"  maxlength="30" type="text" id="inputPassword" class="form-control" name="nome" placeholder="Nome" required autofocus>
                  Senha * <input onKeypress="return somente_numeros(event)" type="text" id="inputPassword" maxlength="12"required></td></tr>
               CPF * <input type="text"   onKeyPress="return Apenas_Numeros(event);" onBlur="validaCPF(this);" id="cpf" class="form-control" size="11" maxlength="11" name="cpf" placeholder="CPF" required>
                Data de Nascimento * <input type="text"  onKeyPress="formata_data(this,document.form.cpf);return Apenas_Numeros(event);" size="11" maxlength="11" id="data" class="form-control" maxLength="13" size="13" name="data_nasc" placeholder="Formato: MM/DD/AAAA" required>
             Telefone * <input type="text"   onKeyPress="fone(this,document.form.data)" id="telefone" class="form-control" name="telefone" maxlength="15" placeholder="Formato: (11)1111-1111" required>
              Email * <input type="email" id="inputPassword" class="form-control" name="email" maxlength="30" placeholder="Email" required>
              Cargo * <select class="selectpicker" name="cargo_func" id="inputCargo">
   
<?php echo $cargo_func;?>
</select>
                  <br><br>
              Estado Cívil *<select name="estado_civil" class="form-melhor" id="estado_civil">
  <option value="none" selected="selected">------------Selecione------------</option>
  <option value="solteiro">Solteiro</option> 
  <option value="casado">Casado</option> 
  <option value="divorciado">Divorciado</option></select> <br><br>
             Dependentes *  <select name="dependentes" id="matricula">
    <option value="none" selected="selected">------------Selecione------------</option>
 <option value="1">1</option>   <option value="2">2</option>   <option value="3">3</option>   <option value="4">4</option> 
  <option value="5">5</option>   <option value="6">6</option>   <option value="7">7</option>   <option value="8">8</option> 
  <option value="9">9</option>   <option value="10">10</option>   
  </select><br><br>
               <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Cadastrar</button><br>
       </div>
                          </form>
        
</body>
</html>