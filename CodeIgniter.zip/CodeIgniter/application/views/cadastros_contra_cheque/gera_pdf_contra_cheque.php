

<?php
$salario_cargo=number_format($salario_cargo, 3, '.', ',');

$mostraHtml = ' 
 
<table border="1" cellpadding="1"  cellspacing="1" style="height: 130px; width: 1000px">
	<tbody>
		<tr><td>Empresa: '.$nome_fantasia.' &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  
               &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; 
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Tipo Folha:Mensalista<br><br>
                        C.N.P.J:'.$cnpj.' <br><br>
                        Nome:'.$nome.'<br><br>
                        Cargo:'.$cargo.'&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                        &nbsp;  &nbsp; &nbsp; 
                        Salário:R$'.$salario_cargo.'<br> </td>
                   
		</tr> 
	</tbody>
</table>	<span style="font-size:9px;">---------------------------------------Confira sempre seus vencimentos - A aréa de Administração está à disposição para esclarecimentos---------------------------------------------------------</span>';


 if ($provento!="" or $desconto!=""){
 $color  = false;  
      $retorno = "";  
 
      $retorno .= "<h2 style=\"text-align:center\">{$this->titulo}</h2>";  
      $retorno .= "<table border='1' width='1000' align='center'>  
           <tr class='header'>  
             <th>Código</td>  
             <th>Descrição</td>  
             <th>Vencimentos</td>  
             <th>Descontos</td>  
       
           </tr>";  

      foreach ($contra_cheque as $dados): 
          //descricao
    $nome = $dados->descricao;
    $parte_descricao = substr($nome, 2);
     //parte codigo
    $nome = $dados->descricao;
    $parte_codigo = substr($nome, 0, 1);
    
         $retorno .= ($color) ? "<tr>" : "<tr class=\"zebra\">";  
         $retorno .= "<td class='destaque'> $parte_codigo</td>";  
         $retorno .= "<td> $parte_descricao</td>";  
         $retorno .= "<td> $dados->provento</td>";  
         $retorno .= "<td> $dados->desconto</td>";  
          
       $retorno .= "</tr>";
       
       $color = !$color;  
      endforeach;  
 $retorno .= ($color) ? "<tr>" : "<tr class=\"zebra\">"; 
 $retorno .= "<td>12</td>";
 $retorno .= "<td>INSS</td>";
 $retorno .= "<td></td>";
 $retorno .= "<td>$inss</td>";
       $retorno .= "</tr>";
       if ($passagem > 0){
        $retorno .= ($color) ? "<tr>" : "<tr class=\"zebra\">"; 
 $retorno .= "<td>13</td>";
 $retorno .= "<td>Vale transporte</td>";
 $retorno .= "<td></td>";
 $retorno .= "<td>$passagem</td>";
       $retorno .= "</tr>";
       }
       
       
$base_vencimento=$salario_cargo + $provento;
$fgts_mes=$base_vencimento * 0.08;
$liquido_depositado=$base_vencimento-$desconto - $inss - $passagem;
//$valor = $liquido_depositado; // valor original
$valor_desconto=$desconto+$inss+$passagem;

$liquido_depositado=number_format($liquido_depositado, 3, '.', ',');
$base_vencimento=number_format($base_vencimento, 3, '.', ',');
$fgts_mes=number_format($fgts_mes, 3, '.', ',');
$salario_cargo=number_format($salario_cargo, 3, '.', ',');
$valor_desconto=number_format($valor_desconto, 3, '.', ',');
$mostraHtml2 = '<p>
	 </p>
        

	 </p><br><br>
<table border="1" cellpadding="1" cellspacing="1" style="height: 130px; width: 1000px">
	<tbody>
		<tr>
			<td>Salário Base<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;R$:'.$salario_cargo.' </td>
                            <td>Base para INSS<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;R$:'.$base_vencimento.' </td>
                                <td>Base Calculo Bruto p/ IR<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;R$:'.$base_vencimento.' </td>
                                    <td>Total de Vencimentos<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;R$:'.$base_vencimento.' </td>
		</tr> 
                <tr>
			<td colspan="2">Base para FGTS<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;R$:'.$base_vencimento.' </td>'
        . '             <td>  FGTS do mês<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;R$:'.$fgts_mes.'</td>
                         <td> Descontos<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;R$:'.$valor_desconto.' </td>
                         </tr> 
                          </tr> 
                        <tr> 
                        <td colspan="4"> Líquido Depositado<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;R$:'.$liquido_depositado.' </td>
		</tr>
               
	</tbody>
</table>

   


'; 
}
 if ($provento=="" or $desconto==""){
     $retorno .= "<br><br><br>"
             . "<td><h2>Contra Cheque deste perído ainda não foi emitido.<h2></td>"; 
 }
      $retorno .= "</table>";  
include('mpdf/mpdf.php');



$mpdf=new mPDF();

$mpdf->WriteHTML($mostraImagem);
$mpdf->WriteHTML($mostraHtml);
$mpdf->WriteHTML( $retorno);
$mpdf->WriteHTML($mostraHtml2);


 
 
//$mpdf->WriteHTML($mostraHtml2);
$mpdf->Output();
exit;

?>