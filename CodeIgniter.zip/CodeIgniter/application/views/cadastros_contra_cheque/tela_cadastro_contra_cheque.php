<html lang="pt-BR">
<head>
    
       <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario_contra_cheque.css">  

   <style type="text/css">
              .celulaesp {padding:50px;}
               .celulaesp2 {padding:10px;}
      </style>
<style type="text/css" media="all">
  body{ font-family:Arial, Helvetica, sans-serif }
  #tudo{ border:#CCCCCC 5px solid;width:700px;margin:0 auto }
  .bd_titulo{
    text-align:left;
    background-color:#CCCCCC;
    font-weight:bold
  }
</style>
</head>
<script type="text/javascript">
function maskIt(w,e,m,r,a){
// Cancela se o evento for Backspace
if (!e) var e = window.event
if (e.keyCode) code = e.keyCode;
else if (e.which) code = e.which;
// Variáveis da função
var txt  = (!r) ? w.value.replace(/[^\d]+/gi,'') : w.value.replace(/[^\d]+/gi,'').reverse();
var mask = (!r) ? m : m.reverse();
var pre  = (a ) ? a.pre : "";
var pos  = (a ) ? a.pos : "";
var ret  = "";
if(code == 9 || code == 8 || txt.length == mask.replace(/[^#]+/g,'').length) return false;
// Loop na máscara para aplicar os caracteres
for(var x=0,y=0, z=mask.length;x<z && y<txt.length;){
if(mask.charAt(x)!='#'){
ret += mask.charAt(x); x++; }
else {
ret += txt.charAt(y); y++; x++; } }
// Retorno da função
ret = (!r) ? ret : ret.reverse()
w.value = pre+ret+pos; }
// Novo método para o objeto 'String'
String.prototype.reverse = function(){
return this.split('').reverse().join(''); };
</script>
<script type="text/javascript">
$(function () {
  function removeCampo() {
	$(".removerCampo").unbind("click");
	$(".removerCampo").bind("click", function () {
	   if($("tr.linhas").length > 1){
		$(this).parent().parent().remove();
	   }
	});
  }
 
  $(".adicionarCampo").click(function () {
	novoCampo = $("tr.linhas:first").clone();
	novoCampo.find("input").val("");
	novoCampo.insertAfter("tr.linhas:last");
	removeCampo();
  });
});
</script>
<script>
    function valida()
{
if(document.getElementById("periodo").selectedIndex == ""){
window.alert("Escolha .");
document.getElementById("periodo").focus();
return false;

    }
}

</script>
<style type="text/css">
#mainselection { overflow:hidden; width:350px;
-moz-border-radius: 9px 9px 9px 9px;
-webkit-border-radius: 9px 9px 9px 9px;
border-radius: 9px 9px 9px 9px;
box-shadow: 1px 1px 11px #330033;
background:  no-repeat scroll 319px 10px #FFFAFA;

}

select { color:#1C1C1C;
font-size:16px; padding:2px 10px; width:320px;

*width:360px; *background:#FFFAFA; 
-webkit-appearance: none; 
-moz-appearance:none;
}
</style>
<style type="text/css">
#box{

    border-radius: 10px;
    }
 
</style>
        <script type="text/javascript" src="http://localhost/CodeIgniter/js/tratamento_campos.js"></script>
<body>

 <div id="box" class="card card-container">

 <form class="form-signin"name="form" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/contra_cheque/cadastra_contra_cheque/cadastrar_contra_cheque">
       
     <table>
         <tr><h2>Gerar Contra Cheque <h2></tr>
       
            <tr><td> Nome Funcionário * <select  name="nome_func" required="required">
    
     <?php echo  $matricula ;?> </select></td>
                
<td algn="right" class="celulaesp">  Período * <select name="periodo" required="required">
     <?php echo  $periodo;?> 
  </select></td> </tr>  
           
  <tr><td>Possui Vale Transporte?<br>
 <input type="radio" name="resposta" value="1"  required="required"> Sim <br>
  <input type="radio" name="resposta" value="2" required="required"> Não<br></td></tr>
          
        
    <tr><td><br><br>Outros Vencimentos/Descontos<br><br></td></tr>
   

 <br>
</table>
<div id="tudo" >
<table border="0" cellpadding="2" cellspacing="4" >
 
 
  <tr><td class="bd_titulo">Descrição</td><td class="bd_titulo">Valor R$</td><td class="bd_titulo"> <font color="#CCCCCC"> __________________________</font>   </td></tr>
  <tr class="linhas">
   
    <td>
     Descrição <select name="descr[]">
         <option value="none" selected="selected">------------Selecione------------</option>
        <option value="1 Férias">Férias</option>
        <option value="2 Horas extras">Horas extras</option>
        <option value="3 Adicional de Insalubridade"> Adicional de Insalubridade</option>
        <option value="4 Adicional de periculosidade">Adicional de periculosidade</option> 
        <option value="5 Adicional noturno">Adiantamento Salarial</option> 
        <option value="6 Salário-família">Salário-família</option> 
        <option value="7 Quebra de Caixa">Quebra de Caixa</option> 
        <option value="8 Décimo Terceiro Salário – Gratificação Natalina">Décimo Terceiro Salário – Gratificação Natalina</option> 
        <option value="9 Faltas, Atrasos e Saídas Antecipadas Injustificadas">Faltas, Atrasos e Saídas Antecipadas Injustificadas</option> 
        <option value="10 Produtividade Mensal">Produtividade Mensal</option> 
        <option value="11 Contribuição Sindical">Contribuição Sindical</option> 
        
       
               
      </select>
    </td>
    <td class="celulaesp2" >Valor<input type="numeric" name="valor[]" onkeyup="maskIt(this,event,'###.###.###.##',true)" size="5" placeholder="R$" /></td>
    
    <td><a href="#" class="removerCampo" title="Remover linha"><img src="http://localhost/CodeIgniter/dist/img/images_excluir.jpg" border="0" /></a></td>
  <td></td><td></td>   </tr>
  <tr><td colspan="4">
        <a href="#" class="adicionarCampo" title="Adicionar item"><img src="http://localhost/CodeIgniter/dist/img/ima_adic.jpg" border="0" /></a>
	<br></td></tr></tr></table></div>

         
           <tr>  <td> <br><button name="botao" class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Gerar</button></td>   </tr>
             </div>
 
                          </form>
    
</body>
</html>

