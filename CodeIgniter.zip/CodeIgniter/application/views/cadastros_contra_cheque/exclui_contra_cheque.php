  
<!DOCTYPE html>
<html lang="pt-BR">
<head>

    <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario.css">  
            
</head>
<body>
 
          <form class="form-signin" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/funcionarios/excluir_usuario/exclui">  
       <div class="card card-container">
    Informe a matrícula que deseja alterar:    <select name="matricula_exclui" id="matricula_exclui">
    <option value="none" selected="selected">------------Selecione------------</option>
<?php echo $matricula;?>
</select>
  
          <button class="btn btn-lg btn-primary btn-block btn-signin" name="botao" type="submit">Excluir</button>

    <?php 
 
    
   
     ?>
          
          </form>