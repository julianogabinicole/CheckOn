<html lang="pt-BR">
<head>
    
       <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario_tela_periodo.css"> 



<body>

 <div class="card card-container">

 <form class="form-signin"name="form" method="post" accept-charset="utf-8" target="_blank" action="http://localhost/CodeIgniter/index.php/contra_cheque/control_gera_pdf/gerar">
       
     <table>
         <tr><h1>Escolher Período do Contra Cheque <h1></tr>
         
<td algn="right" class="celulaesp">  Período * <select name="periodo" required="required">
     <?php echo  $periodo;?> 
  </select></td> </tr>  
       
         
           <tr>  <td> <br><button name="botao" class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Gerar PDF</button></td>   </tr>
            </table>  </div>
 
                          </form>
    
</body>
</html>


