<!DOCTYPE html>
 <script type="text/javascript" src="http://localhost/CodeIgniter/js/trata_campo_cpf.js"></script>
 <script type="text/javascript" src="http://localhost/CodeIgniter/js/tratamento_campos.js"></script>
   <script type="text/javascript" src="http://localhost/CodeIgniter/js/trata_cpf.js"></script> 
    <script type="text/javascript">
			function FormataCnpj(campo, teclapres)
			{
				var tecla = teclapres.keyCode;
				var vr = new String(campo.value);
				vr = vr.replace(".", "");
				vr = vr.replace("/", "");
				vr = vr.replace("-", "");
				tam = vr.length + 1;
				if (tecla != 14)
				{
					if (tam == 3)
						campo.value = vr.substr(0, 2) + '.';
					if (tam == 6)
						campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 5) + '.';
					if (tam == 10)
						campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 3) + '.' + vr.substr(6, 3) + '/';
					if (tam == 15)
						campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 3) + '.' + vr.substr(6, 3) + '/' + vr.substr(9, 4) + '-' + vr.substr(13, 2);
				}
			}
		</script>
<html lang="pt-BR">
<head>
   
    <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario_tela_cadastro_empresa.css">  
            
</head>
<body>

     <p>
				
 <form class="form-signin" id="form" name="form" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/empresas/cadastra_empresa/cadastrar">
      
         
        <div class="card card-container">
                 <table>
         <tr><h2>Cadastrar Empresa <h2></tr>
                   </table>
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
            
              Nome Fantasia *  <input type="text"  class="form-control" maxlength="15" name="nome_fantasia" placeholder="Nome Fantasia" required autofocus>
                  Razão Social * <input type="text" maxlength="15" class="form-control" name="razao_social" placeholder="Razão Social" required>
               CNPJ *</cnpj> <input type="text"  onKeypress="return somente_numeros(event)" maxlength="18" onkeyup="FormataCnpj(this,event)" class="form-control" name="cnpj" placeholder="CNPJ" required>
             Telefone *</data> <input type="text"   onKeyPress="fone(this,document.form.data)" id="telefone" class="form-control" name="telefone" maxlength="13" pattern="\([0-9]{2}\)[0-9]{4}-[0-9]{4}" placeholder="(xx) xxxx-xxxx"  required>
              Email * <input type="email" id="inputPaextssword" class="form-control" name="email" placeholder="Email"  maxlength="40" required>
               <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Cadastrar Empresa</button><br>
         </div>
                          </form>
    </body>
</html>
<body>
		
	</body>