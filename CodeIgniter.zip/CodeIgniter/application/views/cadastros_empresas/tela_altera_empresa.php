
<!DOCTYPE html>
<html lang="pt-BR">
<head>

    <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario.css">  
            
</head>
<body>

  
      <form class="form-signin" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/empresas/alterar_cadastro_empresa/alterar">
               
            <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
             
              Nome Fantasia  <input type="text"  class="form-control" value="<?php echo $nome_fantasia; ?>"maxlength="20"  name="nome_fantasia" placeholder="Nome" required autofocus>
                  Razão Social: <input type="text"  class="form-control" value="<?php echo $razao_social; ?>"  maxlength="20"  name="razao_social" placeholder="Razão Social" required>
               CNPJ: <input type="text" class="form-control" name="cnpj" value="<?php echo $cnpj; ?>"  placeholder="CNPJ" required>

             Telefone: <input type="text"  class="form-control" name="telefone"value="<?php echo $telefone; ?>"  maxlength="13" pattern="\([0-9]{2}\)[0-9]{4}-[0-9]{4}" placeholder="(xx) xxxx-xxxx" required>
              Email: <input type="email"  class="form-control" name="email"value="<?php echo $email; ?>"   required>
               <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Alterar</button><br>

          
               
               </form>
     
</body>
</html>