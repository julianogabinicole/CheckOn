

<?php


 
 $color  = false;  
      $retorno = "";  
 
      
      $retorno .= "<table border='1' width='1000' align='center'>  
           <tr class='header'>  
             <th>Código</td>  
             <th>Matricula</td>  
             <th>Razão Social</td>  
             <th>Nome Fantasia</td> 
             <th>CNPJ</td> 
             <th>Telefone</td> 
             <th>Email</td>  
            
           
           </tr>";  

      foreach ($empresas as $dados): 

    
         $retorno .= ($color) ? "<tr>" : "<tr class=\"zebra\">";  
         $retorno .= "<td class='destaque'> $dados->id</td>";  
         $retorno .= "<td> $dados->matricula</td>";  
         $retorno .= "<td> $dados->razao_social</td>";  
         $retorno .= "<td> $dados->nome_fantasia</td>";  
         $retorno .= "<td> $dados->cnpj</td>"; 
         $retorno .= "<td> $dados->telefone</td>"; 
         $retorno .= "<td> $dados->email</td>";
          
       $retorno .= "<tr>";  
       $color = !$color;  
      endforeach;  



 
      $retorno .= "</table>"; 
       $retorno .= "  <br><br><br><br>";  
$retorno .="  <img src='http://localhost/CodeIgniter/dist/img/img_cheque_on.jpg'  height='40%' width='100%' align='right' ></tr>" ;
include('mpdf/mpdf.php');



$mpdf=new mPDF();

$mpdf->WriteHTML($retorno);

$mpdf->Output();
exit;

?>