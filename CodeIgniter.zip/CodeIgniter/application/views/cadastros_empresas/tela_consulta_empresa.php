<!DOCTYPE html>
 <!--Bootstrap botao atualizar e remover -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">   
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<link rel="stylesheet" 
href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" 
src="http://localhost/CodeIgniter/js/consulta_tela.js"></script>
<script type="text/javascript" 
src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
    $('#minhaTabela').dataTable();
});
</script>
<script type="text/javascript">
function id( el ){
	return document.getElementById( el );
}
window.onload = function(){
	id('form').onsubmit = function(){
		return confirm( 'Tem certeza que deseja excluir empresa?' );
	}
}
</script>
<html lang="pt-BR">
<head>
   
    <meta charset="iso-8859-1" />
     
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario_tela_consulta_empresa.css">  
            
</head>
<body>

         
        <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
    <div class="table-responsive">
<table id="minhaTabela" class="display table" width="100%" >

        <thead>  
          <tr>  
            <th>Código</th> 
            <th>Razão Social</th> 
            <th>Email</th> 
            <th>CNPJ</th> 
            <th>Nome Fantasia</th> 
            <th>Telefone</th> 
         
            <td></td> 
            <td></td> 
          </tr>  
        </thead>  
        <tbody>
<?php foreach($empresas as $dados){ ?>
          <tr> 
            <td><?= $dados->matricula; ?></td> 
            <td><?= $dados->razao_social ; ?></td> 
            <td><?= $dados->email ; ?></td> 
            <td><?= $dados->cnpj ; ?></td>
            <td><?= $dados->nome_fantasia ; ?></td> 
            <td><?= $dados->telefone ; ?></td> 
            
             
      <form class="form-signin" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/empresas/encaminhaLink_empresa/envia_dados">
             <td>   <button class="btn btn-primary"  type="submit">Atualizar</button>
                               <input name="id_altera_empresa" type="hidden" id="id" value="<?= $dados->id; ?>" /></td> 
             </form>
         <form class="form-signin" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/empresas/excluir_empresa/exclui"id="form">
              <td><button class="btn btn-danger"  type="submit">Remover</button>
              <input name="id_remover" type="hidden" id="id_remover" value="<?= $dados->id; ?>" /></td> 
     </form>       
       </tr>
            <?php
          
            } ?>
        </tbody>  
</table>
            <input type="submit" color="#fffff" value=" Gerar PDF " target="_parent" onClick="window.open('http://localhost/CodeIgniter/index.php/empresas/control_gera_pdf/gerar')">
       </div>  
       </div>

