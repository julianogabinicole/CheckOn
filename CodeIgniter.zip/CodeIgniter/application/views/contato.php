<html lang="pt-BR">
<head>
    <title><?php echo $titulo; ?></title>
    <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/form_tela_cad.css">  
<body>
 
<div id="container">
	
 
	<div id="body"> 
 
		<form method="POST" class="form-signin"  accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/contato/envia_email">
 
		   <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
       
                <input type="text" id="inputEmail" class="form-control" name="nome" placeholder="Matricula" required autofocus><br>
                   <input type="email" id="inputPassword" class="form-control" name="email" placeholder="Email" required><br>
               
              
               <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Enviar</button><br>
       
                          </form>
 <td>      
              <a href="http://localhost/CodeIgniter/application/views/tela_login.php" class="forgot-password">
              Voltar
            </a></td>
	</div>
 
</div>
 
</body>
</html>