<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row">
        <p align="center">
            <img src="http://res.cloudinary.com/ci-ncia-da-computa-o/image/upload/v1429073663/site_jmhisz.png">
        </p>
    </div>
    <div class="jumbotron">
        <p>Nome do seu cliente:#nameCliente</p>
        <p>CPF do seu cliente:#cpfCliente</p>
        <p>Email do seu cliente:#emailCliente</p>
    </div>
</div>
</body>
</html>