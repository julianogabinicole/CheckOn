<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.2/css/bootstrap-select.min.css" />
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.2/js/bootstrap-select.min.js"></script>

<style type="text/css">
#mainselection { overflow:hidden; width:350px;
-moz-border-radius: 9px 9px 9px 9px;
-webkit-border-radius: 9px 9px 9px 9px;
border-radius: 9px 9px 9px 9px;
box-shadow: 1px 1px 11px #330033;
background:  no-repeat scroll 319px 10px #FFFAFA;

}

select { color:#1C1C1C;
font-size:16px; padding:2px 10px; width:315px;

*width:360px; *background:#FFFAFA; 
-webkit-appearance: none; 
-moz-appearance:none;
}
</style>
<style type="text/css">
#box{

    border-radius: 10px;
    }
 
</style>



<!DOCTYPE html>
<script type="text/javascript" src="js/jquery-1.2.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.maskedinput-1.1.4.pack.js"/></script>
<html lang="pt-BR">
<head>
       <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario_tela_cadastro_funcionario.css">  
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
        <script type="text/javascript" 
src="http://localhost/CodeIgniter/js/tratamento_campos.js"></script>
  <script type="text/javascript" src="http://localhost/CodeIgniter/js/trata_campo_cpf.js"></script>
   <script type="text/javascript" src="http://localhost/CodeIgniter/js/trata_cpf.js"></script>   
  <link rel="stylesheet" href="dist/css/bootstrap-select.css">      
</head>
<body>


 <form class="form-signin" id="form" name="form" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/funcionarios/cadastra_usuario/cadastrar">
  
       
        <div id="box" class="card card-container">
              <table>
         <tr><h2>Cadastrar Funcionário <h2></tr>
                   </table>
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
            
              Nome do Usuário *  <input onKeypress="return somente_letras(event)"  maxlength="30" type="text" class="form-control" name="nome" placeholder="Nome" required autofocus>
                  R.G * <input onKeypress="return somente_numeros(event)" type="text" maxlength="12" class="form-control" name="rg" placeholder="R.G" required>
               CPF * <input type="text"   onKeyPress="return Apenas_Numeros(event);" onBlur="validaCPF(this);" id="cpf" class="form-control" size="11" maxlength="11" name="cpf" placeholder="CPF" required>
                Data de Nascimento * <input type="text"  onKeyPress="formata_data(this,document.form.cpf);return Apenas_Numeros(event);" size="11" maxlength="11" id="data" class="form-control" maxLength="13" size="13" name="data_nasc" placeholder="Formato: MM/DD/AAAA" required>
             Telefone * <input type="text"   onKeyPress="fone(this,document.form.data)" id="telefone" class="form-control" name="telefone" maxlength="15" pattern="\([0-9]{2}\)[0-9]{4}-[0-9]{4}" placeholder="(xx) xxxx-xxxx" required>
              Email * <input type="email" class="form-control" name="email" maxlength="30" placeholder="Email" required>
              Cargo * <select    name="cargo_func" required="required">
   
<?php echo $cargo_func;?>
</select>
                  <br><br>
           
               <button name="botao" class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Cadastrar</button><br>
       </div>
                          </form>
        
</body>
</html>

 