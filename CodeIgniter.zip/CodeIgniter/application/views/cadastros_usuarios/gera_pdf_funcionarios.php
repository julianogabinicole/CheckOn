

<?php


 
 $color  = false;  
      $retorno = "";  
 
        $retorno .= "<h2 style=\"text-align:center\">{$this->titulo}</h2>"; 
        $retorno .= "<table border='1' width='1000' align='center'>  
           <tr class='header'>  
             <th>Código</td>  
             <th>Matricula</td>  
             <th>Nome</td>  
             <th>RG</td> 
             <th>CPF</td> 
             <th>Data de Nascimento</td> 
             <th>Telefone</td> 
             <th>Email</td> 
             <th>Cargo</td> 
            
           
           </tr>";  

      foreach ($funcionarios as $dados): 

    
         $retorno .= ($color) ? "<tr>" : "<tr class=\"zebra\">";  
         $retorno .= "<td class='destaque'> $dados->id</td>";  
         $retorno .= "<td> $dados->matricula</td>";  
         $retorno .= "<td> $dados->nome</td>";  
         $retorno .= "<td> $dados->rg</td>";  
         $retorno .= "<td> $dados->cpf</td>"; 
         $retorno .= "<td> $dados->data_nasc</td>"; 
         $retorno .= "<td> $dados->tel</td>";
         $retorno .= "<td> $dados->email</td>";
         $retorno .= "<td> $dados->cargo</td>";
        
          
       $retorno .= "<tr>";  
       $color = !$color;  
      endforeach;  



 
      $retorno .= "</table>";  
       $retorno .= "  <br><br><br><br>";  
$retorno .="  <img src='http://localhost/CodeIgniter/dist/img/img_cheque_on.jpg'  height='40%' width='100%' align='right' ></tr>" ;
include('mpdf/mpdf.php');



$mpdf=new mPDF();



$mpdf->WriteHTML($retorno);



 
 
//$mpdf->WriteHTML($mostraHtml2);
$mpdf->Output();
exit;

?>