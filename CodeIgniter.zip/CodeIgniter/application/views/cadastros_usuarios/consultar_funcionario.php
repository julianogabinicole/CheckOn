
<!DOCTYPE html>
<html lang="pt-BR">
<head>

    <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario.css">  
            
</head>
<body>

        
       <?php if(isset($_POST["botao"])){      //echo "botão foi clicado"; ?>
      <form class="form-signin" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/funcionarios/alterar_cadastro/alterar">
                 <?php
               $matricula = $_POST['matricula'];
               $_SESSION['matricula_enviada'] = $matricula ;?>
            <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
             Matrícula: <?php $mostra_matricula=$_POST['matricula'];echo $mostra_matricula ;?><br><br>
              Nome do Usuário  <input type="text" id="inputEmail" class="form-control" value="<?php echo $nome; ?>" name="nome" placeholder="Nome" required autofocus>
                  R.G: <input type="text" id="inputPassword" class="form-control" value="<?php echo $rg; ?>"  name="rg" placeholder="R.G" required>
               CPF: <input type="text" id="inputPassword" class="form-control" name="cpf"value="<?php echo $cpf; ?>"  placeholder="CPF" required>
                Data de Nasc: <input type="text" id="inputPassword" class="form-control"value="<?php echo $data_nasc; ?>"  name="data_nasc" placeholder="Data de Nascimento" required>
             Telefone: <input type="text" id="inputPassword" class="form-control" name="tel"value="<?php echo $tel; ?>"  placeholder="Telefone de Contato" required>
              Email: <input type="email" id="inputPassword" class="form-control" name="email"value="<?php echo $email; ?>"  placeholder="Email" required>
               <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Alterar</button><br>
   <?php    }  
  
   //$matricula_rec=$mostra_matricula;
   ?>
          
               
               </form>
     
</body>
</html>