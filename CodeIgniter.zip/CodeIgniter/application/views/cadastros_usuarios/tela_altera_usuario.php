<style type="text/css">
#mainselection { overflow:hidden; width:350px;
-moz-border-radius: 9px 9px 9px 9px;
-webkit-border-radius: 9px 9px 9px 9px;
border-radius: 9px 9px 9px 9px;
box-shadow: 1px 1px 11px #330033;
background:  no-repeat scroll 319px 10px #FFFAFA;

}

select { color:#1C1C1C;
font-size:16px; padding:2px 10px; width:320px;

*width:360px; *background:#FFFAFA; 
-webkit-appearance: none; 
-moz-appearance:none;
}
</style>
<html lang="pt-BR">
<head>

    <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario_tela_altera_funcionario.css">  
            
</head>
<body>

      <form class="form-signin" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/funcionarios/alterar_cadastro/alterar">
                
            <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
            
              Nome do Usuário  <input type="text"  class="form-control" value="<?php echo $nome; ?>" name="nome" placeholder="Nome" required autofocus>
                  R.G: <input type="text"  class="form-control" value="<?php echo $rg; ?>"  name="rg" placeholder="R.G" required>
               CPF: <input type="text"  class="form-control" name="cpf"value="<?php echo $cpf; ?>"  placeholder="CPF" required>
                Data de Nasc: <input type="text"  class="form-control"value="<?php echo $data_nasc; ?>"  name="data_nasc" placeholder="Data de Nascimento" required>
             Telefone: <input type="text"  class="form-control" name="tel"value="<?php echo $tel; ?>"  placeholder="Telefone de Contato" required>
              Email: <input type="email"  class="form-control" name="email" value="<?php echo $email; ?>"  placeholder="Email" required>
               Cargo:  <select  name="cargo_func" >
    
  <?php echo $cargo_func;?>
             </select>
                  <br><br>
             <br><br> 
         
              <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Alterar</button><br>
   

  
  
          
               
               </form>
     
</body>
</html>