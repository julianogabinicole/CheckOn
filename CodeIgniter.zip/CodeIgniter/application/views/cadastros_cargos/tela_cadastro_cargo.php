<!DOCTYPE html>
        <script type="text/javascript" src="http://localhost/CodeIgniter/js/tratamento_campos.js"></script>
        <SCRIPT>
            
            function maskIt(w,e,m,r,a){
// Cancela se o evento for Backspace
if (!e) var e = window.event
if (e.keyCode) code = e.keyCode;
else if (e.which) code = e.which;
// Variáveis da função
var txt  = (!r) ? w.value.replace(/[^\d]+/gi,'') : w.value.replace(/[^\d]+/gi,'').reverse();
var mask = (!r) ? m : m.reverse();
var pre  = (a ) ? a.pre : "";
var pos  = (a ) ? a.pos : "";
var ret  = "";
if(code == 9 || code == 8 || txt.length == mask.replace(/[^#]+/g,'').length) return false;
// Loop na máscara para aplicar os caracteres
for(var x=0,y=0, z=mask.length;x<z && y<txt.length;){
if(mask.charAt(x)!='#'){
ret += mask.charAt(x); x++; }
else {
ret += txt.charAt(y); y++; x++; } }
// Retorno da função
ret = (!r) ? ret : ret.reverse()
w.value = pre+ret+pos; }
// Novo método para o objeto 'String'
String.prototype.reverse = function(){
return this.split('').reverse().join(''); };
  </SCRIPT>
 <style type="text/css">
#box{

    border-radius: 10px;
    }
 
</style>
<html lang="pt-BR">
<head>
   
    <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario_tela_cadastro_cargo.css">  
            
</head>
<body>

     <p>
				
 <form class="form-signin"  name="form" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/cargos/cadastra_cargo/cadastrar">
      
         
        <div id="box" class="card card-container">
              <table>
         <tr><h2>Cadastrar Cargo <h2></tr>
                   </table>
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
            
              Nome do Cargo  <input type="text"  class="form-control" maxlength="20" name="nome_cargo" placeholder="Cargo" required autofocus>
                 Salário: <input type="text"  class="form-control"  onkeyup="maskIt(this,event,'###.###.###.##',true)" name="salario_cargo" placeholder="R$" required autofocus>
             
               <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Cadastrar Cargo</button><br>
         </div>
                          </form>
    </body>
</html>
<body>
		
	</body>
     