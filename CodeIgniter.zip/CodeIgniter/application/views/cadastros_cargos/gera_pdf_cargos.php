

<?php

 $color  = false;  
      $retorno = "";  
 
        $retorno .= "<h2 style=\"text-align:center\">{$this->titulo}</h2>"; 
        $retorno .= "<table border='1' width='1000' align='center'>  
           <tr class='header'>  
             <th>Código</td>  
             <th>Cargo</td>  
          <th>Salario Cargo</td>  
           </tr>";  

      foreach ($cargo as $dados): 
$salario_cargo=number_format($dados->salario_cargo, 3, '.', ',');
         $retorno .= ($color) ? "<tr>" : "<tr class=\"zebra\">";  
         $retorno .= "<td class='destaque'> $dados->id_cargo</td>";  
         $retorno .= "<td> $dados->cargo_func</td>";  
         $retorno .= "<td> $salario_cargo</td>";  
      $retorno .= "<tr>";  
       $color = !$color;  
      endforeach;  
   $retorno .= "</table>";  
 $retorno .= "  <br><br><br><br>";  
$retorno .="  <img src='http://localhost/CodeIgniter/dist/img/img_cheque_on.jpg'  height='40%' width='100%' align='right' ></tr>" ;
include('mpdf/mpdf.php');

$mpdf=new mPDF();
$mpdf->WriteHTML($retorno);

$mpdf->Output();
exit;

?>