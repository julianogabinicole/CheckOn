
 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"></style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet"></style>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://localhost/CodeIgniter/js/consulta_tela.js"></script>
<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<script>
    
$(document).ready(function(){
    $('#minhaTabela').dataTable();
});
</script>
<script>

function id( el ){
	return document.getElementById( el );
}
window.onload = function(){
	id('form').onsubmit = function(){
		return confirm( 'Tem certeza que deseja excluir cargo ?' );
	}
}
</script>
<style type="text/css">
#box{

    border-radius: 10px;
    }
 
</style>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

<html lang="pt-BR">
<head>
   
    <meta charset="iso-8859-1" />
     
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario_tela_consulta_cargo.css">  
            
</head>
<body>

         
        <div id="box" class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
    <div class="table-responsive">
<table id="minhaTabela" class="display table" width="100%" >
<thead>  
          <tr>   
            <th>Código</th> 
            <th>Cargo</th> 
            <th>Salário</th> 
            <th></th> 
            <th></th> 
          </tr>  
        </thead>  
        <tbody>
<?php foreach($cargos as $dados){ ?>
          <tr> 
              <td><?= $dados->id_cargo; ?></td> 
            <td><?= $dados->cargo_func ; ?></td> 
            <td><?= $dados->salario_cargo ; ?></td> 
           
      <form class="form-signin" method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/cargos/encaminhaLink_cargo/envia_dados">
             <td>   <button class="btn btn-primary"  type="submit">Atualizar</button>
                    <input name="id_altera_cargo" type="hidden" id="id_cargo" value="<?= $dados->id_cargo; ?>" /></td> 
             </form>
         <form class="form-signin"  method="post" accept-charset="utf-8" action="http://localhost/CodeIgniter/index.php/cargos/excluir_cargo/exclui" id="form">
              <td><button class="btn btn-danger"  type="submit">Remover</button>
              <input name="id_remover_cargo" type="hidden" id="id_remover_cargo" value="<?= $dados->id_cargo; ?>" /></td> 
     </form>       
       </tr>
            <?php
          
            } ?>
        </tbody>  
</table>
               <input type="submit" color="#fffff" value=" Gerar PDF " target="_parent" onClick="window.open('http://localhost/CodeIgniter/index.php/cargos/control_gera_pdf_cargo/gerar')">
       </div>  
       </div>
</html>
