<!DOCTYPE html>
<html lang="pt-BR">
<head>
   
    <meta charset="iso-8859-1" />
   <link rel="stylesheet" type="text/css" href="http://localhost/CodeIgniter/css/formulario.css">  
            
</head>
<body>

       
 <td><img src="http://localhost/CodeIgniter/dist/img/img_cheque_on.jpg" height="50%" width="100%" align="right" ></td>
       
                    
        
</body>
</html>