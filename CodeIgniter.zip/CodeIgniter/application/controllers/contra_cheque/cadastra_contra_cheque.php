<?php


class Cadastra_contra_cheque extends CI_Controller{
 
    
  public function envia_dados_select() {
    $this->load->model('model_cadastra_contra_cheque');
        $dados_func= $this->model_cadastra_contra_cheque->get_contra_cheque();
  
foreach($dados_func -> result() as $linha) {
$dados_func = "$linha->vinculacao_func"; 
}
$_SESSION["dados_func"]=$dados_func;
//echo $_SESSION["dados_func"];
  
   $this->load->model('model_cadastra_contra_cheque');
         
 $dados_usuario = $this->model_cadastra_contra_cheque->retorna_dados_usuario_contra_cheque();

    $option_nome = "<option value=''>----------Selecione----------</option>";
foreach($dados_usuario -> result() as $linha) {
$option_nome .= "<option value='$linha->nome'>$linha->nome</option>"; 
}
  $option_matricula = "<option value=''>----------Selecione----------</option>";
foreach($dados_usuario -> result() as $linha) {
$option_matricula.= "<option value='$linha->matricula'>$linha->matricula</option>"; 
}
$option_periodo = "<option value=''>------------Selecione------------</option>";
 $option_periodo.= "<option value='janeiro'>Janeiro</option> ";
  $option_periodo.=  "<option value='fevereiro'>Fevereiro</option> ";
  $option_periodo.= "<option value='marco'>Março</option>";
  $option_periodo.= "<option value='abril'>Abril</option>";
   $option_periodo.="<option value='maio'>Maio</option>";
 $option_periodo.=  "<option value='junho'>Junho</option>";
  $option_periodo.= "<option value='julho'>Julho</option>";
  $option_periodo.=" <option value='agosto'>Agosto</option>";
  $option_periodo.= "<option value='setembro'>Setembro</option>";
  $option_periodo.=" <option value='outubro'>Outubro</option>";
 $option_periodo.=  "<option value='novembro'>Novembro</option>";
   $option_periodo.="<option value='dezembro'>Dezembro</option>";
   

        
$variaveis['nome'] = $option_nome ;
$variaveis['matricula'] = $option_matricula ;
  $variaveis['periodo']=$option_periodo;
 
 //echo $periodo;
       $this->load->view('tela_principal'); 
       $this->load->view('cadastros_contra_cheque/tela_cadastro_contra_cheque',$variaveis); 
      
		}	
                
                
	public function cadastrar_contra_cheque() {
$_SESSION["nome_func_cargo"]=  $_POST["nome_func"];

             $this->load->model("model_cadastra_contra_cheque");// chama o modelo usuarios_model
        $periodo = $this->input->post("periodo");// pega via post o email que venho do formulario
        $nome_func= $this->input->post("nome_func"); // pega via post a senha que venho do formulario
        $ExisteCadastro = $this->model_cadastra_contra_cheque->verifica_cadastro($periodo,$nome_func); // acessa a função buscaPorEmailSenha do modelo
           
        $this->load->model('model_cadastra_contra_cheque');
        $dados_salario= $this->model_cadastra_contra_cheque->get_result();
  
foreach($dados_salario -> result() as $linha) {
$salario_base = "$linha->salario_cargo"; 
}
//echo $salario_base;
 if ($_POST){
  
   $descr 	 = $_POST['descr'];
  $valor 	 = $_POST['valor'];
  // $quantidade	 = $_POST['quantidade'];

$quant_linhas = count($descr);
   }
   // exibindo os dados
   for ($i=0; $i<$quant_linhas; $i++) {
     if  ($descr[$i]=="1 Férias" or $descr[$i]=="3 Adicional de Insalubridade" or $descr[$i]=="2 Horas extras"
                  or $descr[$i]=="4 Adicional de periculosidade" or $descr[$i]=="5 Adicional noturno" 
             or $descr[$i]=="6 Salário-família" or $descr[$i]=="8 Décimo Terceiro Salário – Gratificação Natalina" 
             or $descr[$i]=="6 Salário-família" or $descr[$i]=="10 Produtividade Mensal" and $_POST['nome_func']!=""){ 
	 $data2 = array(
  //'vinculacao_func' =>($_SESSION["matricula_logada"]),
  'nome_func' => $this->input->post('nome_func'),
  'periodo' =>$this->input->post('periodo'),
  'vale_trans' =>  $this->input->post('resposta'),
       'provento' => $valor[$i] ,     
  'descricao' => $descr[$i]
 
      );
      }  
       
          if  ($descr[$i]=="7 Quebra de Caixa" or $descr[$i]=="9 Faltas, Atrasos e Saídas Antecipadas Injustificadas" 
                  or $descr[$i]=="10 Contribuição Sindical" and $_POST['nome_func']!=""){ 
	 $data2 = array(
  //'vinculacao_func' =>($_SESSION["matricula_logada"]),
  'nome_func' => $this->input->post('nome_func'),
  'periodo' =>$this->input->post('periodo'),
  'vale_trans' =>  $this->input->post('resposta'),
       'desconto' => $valor[$i] ,     
  'descricao' => $descr[$i]
 
      );
      }

 $salario_provento=$salario_base;
$desconto_inss=0;
$desconto_passagem=0;
    if  ($descr[$i]=="1 Férias" or $descr[$i]=="3 Adicional de Insalubridade" or $descr[$i]=="2 Horas extras"
                  or $descr[$i]=="4 Adicional de periculosidade" or $descr[$i]=="5 Adicional noturno" 
             or $descr[$i]=="6 Salário-família" or $descr[$i]=="8 Décimo Terceiro Salário – Gratificação Natalina" 
             or $descr[$i]=="6 Salário-família" or $descr[$i]=="10 Produtividade Mensal" ){ 
        
      $salario_provento=$salario_base + $valor[$i];
         
//echo $salario_provento;

     //inss
$V1 = 1.31707;
$V2 = 2.19512;
$V3 = 4.39024;

$inss=0;
if ($salario_provento <= $V1){

         $inss=0.08;
}
if ( $salario_provento> $V1 and  $salario_provento <= $V2 ){
 
         $inss=0.09;
}
if ( $salario_provento > $V2 and  $salario_provento <= $V3 ){
 
         $inss=0.11;
}
         
   $desconto_inss = $salario_provento*($inss/ 100)*100;
   //$salario_prov_inss= $salario_provento - $desconto_inss;
         
   ///////////////////////////
   //desconto passagem
   $desconto_passagem=0;
     if  ($_POST['resposta']==1){
     
   $d_passagem =0.06;
  $desconto_passagem =  $salario_provento*($d_passagem/ 100)*100;
  // $salario_prov_inss_passagem=$salario_prov_inss-$desconto_passagem;
   
     }
   }
   

   $salario_desc=0;
   if  ($descr[$i]=="7 Quebra de Caixa" or $descr[$i]=="9 Faltas, Atrasos e Saídas Antecipadas Injustificadas" 
                  or $descr[$i]=="11 Contribuição Sindical"){ 

       $salario_desc=  $valor[$i];
       
         //$salario_final=$salario_provento - $desconto_inss - $desconto_passagem - $salario_desc;
       }
   
  $salario_final=$salario_provento - $desconto_inss - $desconto_passagem;
  
  $salario_final=$salario_final - $salario_desc;


 if  ($descr[$i]=="1 Férias" or $descr[$i]=="3 Adicional de Insalubridade" or $descr[$i]=="2 Horas extras"
                  or $descr[$i]=="4 Adicional de periculosidade" or $descr[$i]=="5 Adicional noturno" 
             or $descr[$i]=="6 Salário-família" or $descr[$i]=="8 Décimo Terceiro Salário – Gratificação Natalina" 
             or $descr[$i]=="6 Salário-família" or $descr[$i]=="10 Produtividade Mensal"  and $_POST['nome_func']!=""){ 
$data2['total_vencimento']=$salario_provento; 
             }
$data2['salario_base']=$salario_base;
$data2['inss']=$desconto_inss;   
$data2['passagem']=$desconto_passagem; 

$data2['salario_final']=$salario_final;



     
     if($ExisteCadastro==null){  
         
   $this->db->insert('tbl_contra_cheque', $data2);?>
     <SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("A operação foi realizada com sucesso!\n\ "
                 );
         
         window.location="http://localhost/CodeIgniter/index.php/contra_cheque/cadastra_contra_cheque/envia_dados_select";
</SCRIPT> <?php
  } 
  else{?>
      <SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("Já existe cadastro desse funcionário para esse período!\n\
        "
                 );
         
         window.location="http://localhost/CodeIgniter/index.php/contra_cheque/cadastra_contra_cheque/envia_dados_select";
</SCRIPT> <?php
  }
  
  
     }
      
        }} ?>	
       
  