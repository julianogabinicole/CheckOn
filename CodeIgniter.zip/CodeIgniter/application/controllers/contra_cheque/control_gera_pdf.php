

<?php

class Control_gera_pdf  extends CI_Controller{ 
 
public function gerar(){
   $periodo= $_POST['periodo'];
   $_SESSION["periodo"]=$_POST['periodo'];
 
   
  $this->load->model('model_cadastra_contra_cheque');
        $dados_empresa= $this->model_cadastra_contra_cheque->get_vinc_func();
  
       $this->load->model('model_cadastra_contra_cheque');
 $dados_contra_cheque= $this->model_cadastra_contra_cheque->get_dados_contra_cheque();
         
 $this->load->model('model_cadastra_contra_cheque');
 $dados_salario= $this->model_cadastra_contra_cheque->get_dados_salario();
  
foreach($dados_salario -> result() as $linha) {
$salario_liquido = "$linha->salario_cargo"; 

}     
     
foreach($dados_empresa -> result() as $linha) {
$data_nome_fantasia= "$linha->nome_fantasia"; 
$data_cnpj= "$linha->cnpj"; 
}
// $this->load->model('model_cadastra_contra_cheque');
 // $dados_contra_cheque= $this->model_cadastra_contra_cheque->get_result();
  foreach($dados_contra_cheque -> result() as $linha) {
$data_nome= "$linha->nome"; 
$data_cargo= "$linha->cargo"; 

}
 $this->load->model('model_cadastra_contra_cheque');
 $dados_soma= $this->model_cadastra_contra_cheque->get_soma_contra_cheque();
  
foreach($dados_soma -> result() as $linha) {
$soma_desconto = "$linha->desconto"; 
$soma_provento= "$linha->provento"; 
$soma_inss= "$linha->inss"; 
$soma_passagem= "$linha->passagem"; 

}  

  
          
   $data['contra_cheque']= $this->db->where('periodo', $periodo  ); 
  $data['contra_cheque']= $this->db->where('nome_func', $_SESSION["matricula_logada"]  );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
   $data['contra_cheque']= $this->db->get('tbl_contra_cheque')->result();
   
//echo $data_nome;
$data['nome_fantasia']=$data_nome_fantasia;
$data['cnpj']=$data_cnpj;
$data['nome']=$data_nome;
$data['cargo']=$data_cargo;
$data['salario_cargo']=$salario_liquido;
$data['desconto']=$soma_desconto;
$data['provento']=$soma_provento;
$data['inss']=$soma_inss;
$data['passagem']=$soma_passagem;
//echo $data_soma;

   $this->load->view('tela_principal');  
  $this->load->view('cadastros_contra_cheque/gera_pdf_contra_cheque',$data);

// $this->load->view('tela_principal'); 
 
 //$this->load->view('teste',$data);
		}
}