<?php
class Control_gera_pdf_contra_cheque extends CI_Controller {
    

   public function tela_escolha_periodo() {
         $this->load->model('model_cadastra_contra_cheque');
        $dados_func= $this->model_cadastra_contra_cheque->get_contra_cheque();
  
foreach($dados_func -> result() as $linha) {
$dados_func = "$linha->vinculacao_func"; 
}
$_SESSION["dados_func"]=$dados_func;    
     	echo $_SESSION["dados_func"];
        
        $option_periodo = "<option value=''>------------Selecione------------</option>";
 $option_periodo.= "<option value='janeiro'>Janeiro</option> ";
  $option_periodo.=  "<option value='fevereiro'>Fevereiro</option> ";
  $option_periodo.= "<option value='marco'>Março</option>";
  $option_periodo.= "<option value='abril'>Abril</option>";
   $option_periodo.="<option value='maio'>Maio</option>";
 $option_periodo.=  "<option value='junho'>Junho</option>";
  $option_periodo.= "<option value='julho'>Julho</option>";
  $option_periodo.=" <option value='agosto'>Agosto</option>";
  $option_periodo.= "<option value='setembro'>Setembro</option>";
  $option_periodo.=" <option value='outubro'>Outubro</option>";
 $option_periodo.=  "<option value='novembro'>Novembro</option>";
   $option_periodo.="<option value='dezembro'>Dezembro</option>";
    $variaveis['periodo']=$option_periodo;
    
        $this->load->view('tela_principal');  
	$this->load->view('cadastros_contra_cheque/tela_escolha _periodo',$variaveis); 
        }
        
       }