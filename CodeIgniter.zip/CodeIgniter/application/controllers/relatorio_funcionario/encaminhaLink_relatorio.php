<?php


class EncaminhaLink_relatorio extends CI_Controller {
     //  function mostrar_tela_relatorio() {
        //$this->load->view('tela_principal');  
	//$this->load->view('gerar_relatorio/mostra_relatorio'); 		
		//}
            function envia_dados() {
                
                
     $this->load->model('pessoas_model');
       
$matricula = $this->pessoas_model->retorna_dados();
        
	    $option = "<option value=''></option>";
foreach($matricula -> result() as $linha) {
$option .= "<option value='$linha->matricula'>$linha->matricula</option>"; 
}
$variaveis['nome'] = $option;

 
   
        $this->load->view('tela_principal'); 
 
       $this->load->view('gerar_relatorio/mostra_relatorio',$variaveis); 		
		}
}