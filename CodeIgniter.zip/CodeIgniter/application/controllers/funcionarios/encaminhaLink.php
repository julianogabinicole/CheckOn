<?php


class EncaminhaLink extends CI_Controller {
       function tela_cadastro() {
           $this->load->model('pessoas_model');
   $envia_nome = $this->pessoas_model->retorna_mostra_nome();
           
        $this->load->model('cadastra_usuario_model');
       
   $matricula_empresa= $this->cadastra_usuario_model->consulta_dados_cargo();
        
	    $option = "<option value=''>-------Selecione--------</option>";
foreach($matricula_empresa -> result() as $linha) {
$option .= "<option value='$linha->cargo_func'>$linha->cargo_func</option>"; 
}
 
$variaveis['cargo_func'] = $option;

 

        $this->load->view('tela_principal',$envia_nome);  
	$this->load->view('cadastros_usuarios/tela_cadastro_usuario_logado',$variaveis); 		
		}
        
                 function altera_cadastro() {
   $this->load->model('pessoas_model');
   $envia_nome = $this->pessoas_model->retorna_mostra_nome();
                  
   $this->load->model('cadastra_usuario_model');
       
   $matricula = $this->cadastra_usuario_model->retorna_alteracao();
        
	    $option = "<option value=''></option>";
foreach($matricula -> result() as $linha) {
$option .= "<option value='$linha->matricula'>$linha->matricula</option>"; 
}
 
$variaveis['matricula'] = $option;
 
   
        $this->load->view('tela_principal'); 
 
       $this->load->view('cadastros_usuarios/tela_altera_usuario',$variaveis); 		
		}
                  function envia_dados() {

                   $this->load->model('cadastra_usuario_model');
       
$dados_retorna = $this->cadastra_usuario_model->retorna_usuario();
        
	  // echo $matricula_retorna;
 
   
        $this->load->view('tela_principal',$envia_nome); 
 
       $this->load->view('cadastros_usuarios/tela_altera_usuario',$dados_retorna); 		
		}
                
                  function envia_consulta_func() {
$_SESSION["id_consulta"] =  $_POST["id_altera"];
 
   
        //$this->load->model('cadastra_usuario_model');
        $this->load->model('cadastra_usuario_model');
       $dados_func = $this->cadastra_usuario_model->retorna_usuario();
       
   $dados_cargo = $this->cadastra_usuario_model->consulta_dados_cargo();
   
    $cargo_func = "<option value=''>----------Selecione----------</option>";
foreach($dados_cargo -> result() as $linha) {
$cargo_func.= "<option value='$linha->cargo_func'>$linha->cargo_func</option>"; 
}
   
 
foreach($dados_func -> result() as $linha) {
$nome_func = "$linha->nome"; 
$rg= "$linha->rg"; 
$cpf = "$linha->cpf"; 
$data_nasc = "$linha->data_nasc"; 
$tel = "$linha->tel"; 
$email = "$linha->email"; 


}   
 $data['nome']=$nome_func;
$data['rg']=$rg;
$data['cpf']=$cpf;
$data['data_nasc']=$data_nasc;
$data['tel']=$tel;
$data['email']=$email;
$data['cargo_func'] = $cargo_func;
           




   
        $this->load->view('tela_principal'); 
 
       $this->load->view('cadastros_usuarios/tela_altera_usuario',$data); 
       //$this->load->view('cadastros_usuarios/tela_altera_usuario',$variaveis,$dados_retorna); 

       
		}
                 function alterar() {
   $this->load->model('pessoas_model');
   $envia_nome= $this->pessoas_model->retorna_mostra_nome();
$_SESSION["id_consulta"] =  $_POST["id"];
                   $this->load->model('cadastra_usuario_model');
       
$dados_retorna = $this->cadastra_usuario_model->retorna_usuario();
        
	  // echo $matricula_retorna;
 
   
        $this->load->view('tela_principal',$envia_nome); 
 
       $this->load->view('cadastros_usuarios/tela_altera_usuario',$dados_retorna); 		
		}
}
