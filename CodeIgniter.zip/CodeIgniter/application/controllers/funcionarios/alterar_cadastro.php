<?php
 
class Alterar_cadastro extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "alterar")
$this->alterar(); 
else $this->index();

}  
    function alterar() {

$this->load->model('cadastra_usuario_model', 'model', TRUE);
           // echo $_POST['nome']; 
             //  $nome= $_POST['nome'];
		$data['nome'] = $this->input->post('nome');
                $data['rg'] = $this->input->post('rg');
                $data['cpf'] = $this->input->post('cpf');
                $data['data_nasc'] = $this->input->post('data_nasc');
                $data['tel'] = $this->input->post('tel');
                $data['email'] = $this->input->post('email');
                  $data['estado_civil'] = $this->input->post('estado_civil');
                $data['cargo'] = $this->input->post('cargo_func');
             
  		/* Carrega o modelo */
		
 		/* Chama a função alterae do modelo */
                 
 $this->model->alterar_cadastro_usuario($data) ;?>
	<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("A operação foi realizada com sucesso!");
         
         window.location="http://localhost/CodeIgniter/index.php/funcionarios/consultar/envia_consulta";
</SCRIPT> <?php
}}?>