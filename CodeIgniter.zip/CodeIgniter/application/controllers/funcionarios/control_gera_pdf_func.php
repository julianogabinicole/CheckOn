

<?php


class Control_gera_pdf_func  extends CI_Controller{ 

  
public function gerar(){
    

  $data['funcionarios']= $this->db->where('vinculacao_func', $_SESSION["matricula_logada"]  );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
  $data['funcionarios']= $this->db->get('tbl_cadastro_usuarios')->result();
        $this->load->view('tela_principal'); 
       $this->load->view('cadastros_usuarios/gera_pdf_funcionarios',$data); 		
		}
}