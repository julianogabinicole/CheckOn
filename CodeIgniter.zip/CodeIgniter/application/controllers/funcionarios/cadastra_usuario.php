<?php

class Cadastra_usuario extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "cadastrar")
$this->cadastrar(); 
else $this->index();

}  
 
  function cadastrar() {
 
       $this->load->model('cadastra_usuario_model');
       
$matricula = $this->cadastra_usuario_model->ultimo_campo_id();
     // $soma=1000;  
	    $option = "<option value=''></option>";
foreach($matricula -> result() as $linha) {
$option .= "<option value='$linha->id'>$linha->id</option>"; 
}
$valor="F";
echo $matricula=$valor. "" .rand(10000, 50000);
echo $matricula;
      //print_r($matri) ;
                $data['vinculacao_func']=$_SESSION["matricula_logada"];
		$data['matricula'] = $matricula;
                $data['nome'] = $this->input->post('nome');
                $data['rg'] = $this->input->post('rg');
                $data['cpf'] = $this->input->post('cpf');
                $data['data_nasc'] = $this->input->post('data_nasc');
                $data['tel'] = $this->input->post('telefone');
                $data['email'] = $this->input->post('email');
                $data['cargo'] = $this->input->post('cargo_func');
                $data['estado_civil'] = $this->input->post('estado_civil');
                $data['dependentes'] = $this->input->post('dependentes');
  		/* Carrega o modelo */
		$this->load->model('cadastra_usuario_model', 'model', TRUE);
 		/* Chama a função inserir do modelo */
       $email_matricula = $_POST['email'];
      $nome_email = $_POST['nome'];
//echo $email_matricula;
$this->load->library('email');
$this->email->from($nome_email);
$this->email->to($email_matricula);
$this->email->subject('Favor verificar sua matrícula');
$this->email->message("Sua matrícula será:$matricula");
$this->email->send();

$this->model->cadastrar($data) ;
  }} ?><SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("A operação foi realizada com sucesso!\n\
          Sua matrícula foi enviada para seu email"
                 );
         
         window.location="http://localhost/CodeIgniter/index.php/funcionarios/encaminhaLink/tela_cadastro";
</SCRIPT> <?php   


