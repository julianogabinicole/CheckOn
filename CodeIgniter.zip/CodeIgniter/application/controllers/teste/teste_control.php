<?php


class Teste_control extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "cadastrar")
$this->cadastrar(); 
else $this->index();

}  
    

  function cadastrar() {
 

              
  	
//echo $email_matricula;
$this->load->library('email');
$this->email->from('fisko157@gmail.com  ');
$this->email->to('fisko157@gmail.com ');
$this->email->subject('');
$this->email->message("teste");
$this->email->send();
?>
<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
       
         
         window.location="http://localhost/CodeIgniter/index.php/teste/teste_control/cadastrar";
</SCRIPT> 
<?php } }

