 <?php     
 class Contato extends CI_Controller {
     
 function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "envia_email")
$this->envia_email(); 
else $this->index();

}
 
 function envia_email() { 
   
    $nome= $_POST['nome'];
    $email= $_POST['email'];
    $data['senha'] = $this->input->post('senha');
    $this->load->model('pessoas_model', 'model', TRUE);
    $QtdeCaracteres = 8;
$CaracteresAceitos = 'abcdxywzABCDZYWZ0123456789';
$max = strlen($CaracteresAceitos)-1;
$password = null;
 for($i=0; $i < $QtdeCaracteres; $i++) {
         $password .= $CaracteresAceitos{mt_rand(0, $max)};
 }
echo "Nova Senha: ".$senha = $password;
echo "<br/>";
echo "Nova Senha Criptografada: ".$senha_criptografada = md5($password);
 $data['senha']=$senha_criptografada;
 
              
 
   
    
 $ExisteUsuarioePassword=$this->model->ValidarUsuarioEmail($_POST['email']);
 $ExisteUsuarioeMatricula=$this->model->ValidarMatriculaEmpresa($_POST['nome']);//   comprovamos que o usuario exista na base de dados e a password inserida seja correta
   if($ExisteUsuarioePassword and $ExisteUsuarioeMatricula){   // A variavel $ExisteUsuarioePassoword recebe valor TRUE se o usuario existe e FALSE em caso negativo. Este valor é determinado pelo modelo.                              
       $this->model->atualizar_senha($data,$nome) ;
       ?> <SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("Email enviado com sucesso!");
         window.location="http://localhost/CodeIgniter/application/views/tela_login.php";
</SCRIPT><?php
$this->load->library('email');
 $this->email->from($nome,$nome);
$this->email->to($email);
$this->email->subject('Favor verificar sua nova senha');
$this->email->message("Sua nova senha será:$senha");
 $this->email->send();
 
 
 

   } else {
       
        ?> <SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("Favor inserir matricula e email corretos!");
         window.location="http://localhost/CodeIgniter/application/views/contato.php";
</SCRIPT><?php
     
 }
 
 
   }
 }
 

     
?>