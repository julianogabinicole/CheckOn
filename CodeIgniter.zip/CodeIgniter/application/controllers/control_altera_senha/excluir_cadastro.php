<?php


   
class Excluir_cadastro extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "exclui")
$this->exclui(); 
else $this->index();

}  
    function exclui() {
       //echo $_POST["id_remover_cargo"];
 $id_remover_cadastro= $_SESSION["matricula_logada"] ;
        
    $this->load->model('cadastra_usuario_model', 'model', TRUE);             
 $this->model->excluir_cadastro( $id_remover_cadastro) ;
	}} ?><SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("Cadastro excluido com sucesso!");
         
         window.location="http://localhost/CodeIgniter/index.php";
</SCRIPT><?php
