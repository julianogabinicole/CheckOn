<?php
 
class Alt_senha extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "alterar")
$this->alterar(); 
else $this->index();

}  
   function alterar() {

$this->load->model('pessoas_model', 'model', TRUE);
           $nova_senha= $_POST['nova_senha'];
                $codificada  = md5($nova_senha);
		//$senha= $_POST['senha'];
              $data['senha'] =$codificada  ;

 $this->model->alterar_senha_usuario($data) ;?>
	<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("A operação foi realizada com sucesso!!");
         
         window.location="http://localhost/CodeIgniter/index.php/";
</SCRIPT> <?php
}

   }?>