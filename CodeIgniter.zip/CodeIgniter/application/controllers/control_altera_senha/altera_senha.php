<?php

 function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "mudar_senha")
$this->mudar_senha(); 
else $this->index();
}  
class Altera_senha extends CI_Controller {
  
      function mudar_senha() {
                                           
         // echo $_SESSION["matricula_logada"] ;
          
        $this->load->view('tela_principal');  
	$this->load->view('alteracao_de_senha/view_altera_senha'); 			
		}
        function altera() { 
           $this->load->view('tela_principal');  
	$this->load->view('alteracao_de_senha/tela_altera_senha');    
            
            
        }         
 }
 