<?php


class EncaminhaLink_empresa extends CI_Controller {
       function tela_cadastro() {
           $this->load->model('pessoas_model');
   $envia_nome= $this->pessoas_model->retorna_mostra_nome();
        $this->load->view('tela_principal',$envia_nome);  
	$this->load->view('cadastros_empresas/tela_cadastro_empresa'); 		
	                        }                
                
         function altera_cadastro() {
         $this->load->model('cadastra_empresa_model');
       
$matricula = $this->cadastra_empresa_model->retorna_alteracao();
        
	
 
   
        $this->load->view('tela_principal'); 
 
       $this->load->view('cadastros_empresas/tela_altera_empresa',$variaveis); 		
		}
                  function envia_dados() {
                  $_SESSION["id_empresa"] =  $_POST["id_altera_empresa"];
                   $this->load->model('cadastra_empresa_model');
       
$dados_retorna = $this->cadastra_empresa_model->retorna_usuario();
        
	  // echo $matricula_retorna;
 $this->load->model('pessoas_model');
           $envia_nome= $this->pessoas_model->retorna_mostra_nome();
   
        $this->load->view('tela_principal',$envia_nome); 
 
       $this->load->view('cadastros_empresas/tela_altera_empresa',$dados_retorna); 		
		}
                  function exclui_empresa() {
                $this->load->model('pessoas_model');
           $envia_nome= $this->pessoas_model->retorna_mostra_nome();
                      
                      
                       $this->load->model('cadastra_empresa_model');
       
$matricula = $this->cadastra_empresa_model->retorna_alteracao();
        
	    $option = "<option value=''></option>";
foreach($matricula -> result() as $linha) {
$option .= "<option value='$linha->matricula'>$linha->matricula</option>"; 
}
 
$variaveis['matricula'] = $option;
 
  
        $this->load->view('tela_principal',$envia_nome); 
 
       $this->load->view('cadastros_empresas/exclui_empresa',$variaveis); 		
		}
                  function envia_dados_pdf() {
               
                 $this->load->model('pessoas_model');
   $envia_nome= $this->pessoas_model->retorna_mostra_nome();
  $dados['empresas']= $this->db->where('vinculacao_empresa', $_SESSION["matricula_logada"]  );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
      $dados['empresas']= $this->db->get('tbl_cadastro_empresas')->result();;
//$dados['empresas'] = $this->db->get('tbl_cadastro_empresas')->result();
        $this->load->view('tela_principal',$envia_nome); 
 
       $this->load->view('cadastros_empresas/gera_pdf_empresa',$dados); 		
		}
    //put your code here
}
