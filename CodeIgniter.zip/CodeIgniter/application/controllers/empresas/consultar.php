<?php


class consultar extends CI_Controller{ 
   function envia_consulta() {
       $this->load->model('pessoas_model');
   $envia_nome= $this->pessoas_model->retorna_mostra_nome();
  $dados['empresas']= $this->db->where('vinculacao_empresa', $_SESSION["matricula_logada"]  );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
      $dados['empresas']= $this->db->get('tbl_cadastro_empresas')->result();
//$dados['empresas'] = $this->db->get('tbl_cadastro_empresas')->result();
        $this->load->view('tela_principal',$envia_nome); 
 
       $this->load->view('cadastros_empresas/tela_consulta_empresa',$dados); 		
		
       
}
}
  

    
