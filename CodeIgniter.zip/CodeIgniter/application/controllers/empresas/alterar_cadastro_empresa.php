<?php

//session_start();
   
class Alterar_cadastro_empresa extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "alterar")
$this->alterar(); 
else $this->index();

}  
    function alterar() {

$this->load->model('cadastra_empresa_model', 'model', TRUE);
           // echo $_POST['nome']; 
               $nome_fantasia= $_POST['nome_fantasia'];
		$data['nome_fantasia'] = $this->input->post('nome_fantasia');
                $data['razao_social'] = $this->input->post('razao_social');
                $data['cnpj'] = $this->input->post('cnpj');
                $data['telefone'] = $this->input->post('telefone');
                $data['email'] = $this->input->post('email');
  		/* Carrega o modelo */
		
 		/* Chama a função alterae do modelo */
                 echo $nome_fantasia;
 $this->model->alterar_cadastro_empresa($data,$nome) ;}} ?>
	<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("A operação foi realizada com sucesso!");
         
         window.location="http://localhost/CodeIgniter/index.php/empresas/consultar/envia_consulta";
</SCRIPT> <?php
?>