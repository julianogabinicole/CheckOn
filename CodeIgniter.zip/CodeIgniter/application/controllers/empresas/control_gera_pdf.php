

<?php


class Control_gera_pdf  extends CI_Controller{ 

  
public function gerar(){
    

  $data['empresas']= $this->db->where('vinculacao_empresa', $_SESSION["matricula_logada"]  );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
   $data['empresas']= $this->db->get('tbl_cadastro_empresas')->result();
        $this->load->view('tela_principal'); 
 
       $this->load->view('cadastros_empresas/gera_pdf_empresa',$data); 		
		}
}