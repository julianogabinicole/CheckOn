<?php


class Cadastra_empresa extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "cadastrar")
$this->cadastrar(); 
else $this->index();

}  
    

  function cadastrar() {
 
	/* Carrega a biblioteca do CodeIgniter responsável pela validação dos formulários */
	$this->load->library('form_validation');
 
	/* Define as tags onde a mensagem de erro será exibida na página */
	$this->form_validation->set_error_delimiters('<span>', '</span>');
 
	/* Define as regras para validação */
        
   
	
        $this->form_validation->set_rules('nome_fantasia', 'Nome Fantasia', 'required|max_length[40]');
	$this->form_validation->set_rules('razao_social', 'Razão Social', 'required|max_length[20]');
        $this->form_validation->set_rules('cnpj', 'CNPJ', 'required|max_length[20]');
        $this->form_validation->set_rules('telefone', 'Telefone', 'required|max_length[20]');
        $this->form_validation->set_rules('email', 'Email', 'required|max_length[40]');
 
	/* Executa a validação e caso houver erro chama a função index do controlador */
	if ($this->form_validation->run() === FALSE) {
		
	/* Senão, caso sucesso: */	
	} 
            
        else{
           
 
       $this->load->model('cadastra_empresa_model');
       
$matricula = $this->cadastra_empresa_model->ultimo_campo_id();
     // $soma=1000;  
	    $option = "<option value=''></option>";
foreach($matricula -> result() as $linha) {
$option .= "<option value='$linha->id'>$linha->id</option>"; 
}
$valor="E";
 $matricula=$valor. "" .rand(10000, 50000);
echo $matricula;
      //print_r($matri) ;
                 $data['vinculacao_empresa']=$_SESSION["matricula_logada"];
		$data['matricula'] = $matricula;
                $data['nome_fantasia'] = $this->input->post('nome_fantasia');
                $data['razao_social'] = $this->input->post('razao_social');
                $data['cnpj'] = $this->input->post('cnpj');
                $data['telefone'] = $this->input->post('telefone');
                $data['email'] = $this->input->post('email');
  		/* Carrega o modelo */
		$this->load->model('cadastra_empresa_model', 'model', TRUE);
 		/* Chama a função inserir do modelo */
    echo $email_matricula = $_POST['email'];
   echo  $nome_email = $_POST['nome_fantasia'];
//echo $email_matricula;
$this->load->library('email');
$this->email->from($nome_email);
$this->email->to($email_matricula);
$this->email->subject('Favor verificar sua matrícula');
$this->email->message("Sua matrícula será:$matricula");
$this->email->send();

$this->model->cadastrar($data) ;
  }}} ?><SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("Empresa cadastrada com sucesso!\n\
          Sua matrícula foi enviada para seu email"
                 );
         
         window.location="http://localhost/CodeIgniter/index.php/empresas/encaminhaLink_empresa/tela_cadastro";
</SCRIPT> <?php  


