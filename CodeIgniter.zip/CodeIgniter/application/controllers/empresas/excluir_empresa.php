<?php

//session_start();
   
class Excluir_empresa extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "exclui")
$this->exclui(); 
else $this->index();

}  
    function exclui() {

      $id_exclui_empresa= $_POST["id_remover"];
      
    $this->load->model('cadastra_empresa_model', 'model', TRUE);             
 $this->model->excluir_dado($id_exclui_empresa) ;
	}} ?><SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("A operação foi realizada com sucesso!!");
         
         window.location="http://localhost/CodeIgniter/index.php/empresas/consultar/envia_consulta";
</SCRIPT><?php
