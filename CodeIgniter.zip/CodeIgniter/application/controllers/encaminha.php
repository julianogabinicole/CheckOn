<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Encaminha extends CI_Controller {
 
function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "emite")
$this->emite(); 
else $this->index();
//if($method == "abre_cadastro")
//$this->abre_cadastro(); 
//else $this->index();

}
 
function emite() {
    
$_SESSION["matricula_logada"] =  $_POST["nome"];
   $_SESSION["senha_logada"] =  $_POST["senha"];

   
                   
		$this->load->model('pessoas_model', 'model', TRUE);
 		/* Chama a função inserir do modelo */
             //  $ExisteUsuarioePassword=$this->model->ValidarUsuarioSenha($_POST['senha']);  
               $ExisteUsuarioeNome=$this->model->ValidarUsuarioNome($_POST['nome']); 
                //   comprovamos que o usuario exista na base de dados e a password inserida seja correta
            if($ExisteUsuarioeNome or $_SESSION["matricula_logada"]=="admin" and $_SESSION["senha_logada"]=='123456'){   // A variavel $ExisteUsuarioePassoword recebe valor TRUE se o usuario existe e FALSE em caso negativo. Este valor é determinado pelo modelo.
                                            
      $this->load->view('tela_principal'); 
        $this->load->view('tela_imagem');
	//$this->load->view('teste_template'); 		
		}
   else{
      $this->load->view('tela_login');   
      
   }
   
   

       
       
   }
}




?>