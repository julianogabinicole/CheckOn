<?php


class EncaminhaLink_cargo extends CI_Controller {
       function tela_cadastro_cargo() {
           $this->load->model('pessoas_model');
   $envia_nome = $this->pessoas_model->retorna_mostra_nome();
           
    
        $this->load->view('tela_principal',$envia_nome);  
	$this->load->view('cadastros_cargos/tela_cadastro_cargo'); 		
		}
        
                 function altera_cadastro() {
   $this->load->model('pessoas_model');
   $envia_nome = $this->pessoas_model->retorna_mostra_nome();
                  
   $this->load->model('cadastra_usuario_model');
       
   $matricula = $this->cadastra_usuario_model->retorna_alteracao();
        
	    $option = "<option value=''></option>";
foreach($matricula -> result() as $linha) {
$option .= "<option value='$linha->matricula'>$linha->matricula</option>"; 
}
 
$variaveis['matricula'] = $option;
 
   
        $this->load->view('tela_principal'); 
 
       $this->load->view('cadastros_usuarios/tela_altera_usuario',$variaveis); 		
		}
                  function envia_dados() {
$_SESSION["id_consulta_cargo"]=$_POST["id_altera_cargo"];
                   $this->load->model('cadastra_cargo_model');
       
$dados_retorna = $this->cadastra_cargo_model->retorna_cargo();
        
	  // echo $matricula_retorna;
   $this->load->model('pessoas_model');
   $envia_nome= $this->pessoas_model->retorna_mostra_nome();
   
        $this->load->view('tela_principal',$envia_nome); 
 
       $this->load->view('cadastros_cargos/tela_altera_cargo',$dados_retorna); 		
		}
                
                  function envia_consulta_func() {
$_SESSION["id_consulta_cargo"] =  $_POST["id_cargo"];
    $this->load->model('pessoas_model');
   $envia_nome= $this->pessoas_model->retorna_mostra_nome();
                   $this->load->model('cadastra_cargo_model');
       
$dados_retorna = $this->cadastra_cargo_model->retorna_cargo();
        
	  // echo $matricula_retorna;
 
   
        $this->load->view('tela_principal',$envia_nome); 
 
       $this->load->view('cadastros_usuarios/tela_altera_usuario',$dados_retorna); 		
		}
                 function alterar() {
   $this->load->model('pessoas_model');
   $envia_nome= $this->pessoas_model->retorna_mostra_nome();
$_SESSION["id_consulta"] =  $_POST["id"];
                   $this->load->model('cadastra_usuario_model');
       
$dados_retorna = $this->cadastra_usuario_model->retorna_usuario();
        
	  // echo $matricula_retorna;
 
   
        $this->load->view('tela_principal',$envia_nome); 
 
       $this->load->view('cadastros_usuarios/tela_altera_usuario',$dados_retorna); 		
		}
}
