<?php


   
class Excluir_cargo extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "exclui")
$this->exclui(); 
else $this->index();

}  
    public function exclui() {
       echo $_POST["id_remover_cargo"];
 $id_remover_cargo= $_POST["id_remover_cargo"];
        
    $this->load->model('cadastra_cargo_model', 'model', TRUE);             
 $this->model->excluir_dado($id_remover_cargo) ;
	}} ?><SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("Cargo excluido com sucesso!");
         
         window.location="http://localhost/CodeIgniter/index.php/cargos/consultar_cargo/envia_consulta";
</SCRIPT><?php
