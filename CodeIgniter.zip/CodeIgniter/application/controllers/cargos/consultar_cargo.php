<?php


class Consultar_cargo extends CI_Controller{ 
   function envia_consulta() {
           $this->load->model('pessoas_model');
           $envia_nome= $this->pessoas_model->retorna_mostra_nome();
       
       $dados['cargos']= $this->db->where('matricula_empresa', $_SESSION["matricula_logada"]  );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
     $dados['cargos']= $this->db->get('tbl_cargo')->result();
//$dados['empresas'] = $this->db->get('tbl_cadastro_empresas')->result();
//$dados['usuarios'] = $this->db->get('tbl_cadastro_usuarios')->result();
        $this->load->view('tela_principal',$envia_nome); 
 
       $this->load->view('cadastros_cargos/tela_consulta_cargo',$dados); 		
		
       
}
}
  

    