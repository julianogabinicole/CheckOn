

<?php


class Control_gera_pdf_cargo extends CI_Controller{ 

  
public function gerar(){
    

  $data['cargo']= $this->db->where('matricula_empresa', $_SESSION["matricula_logada"]  );   //   A consulta é efetuada mediante Active Record. Uma maneira alternativa, e em linguagem mais simples, de gerar as consultas Sql.
  $data['cargo']= $this->db->get('tbl_cargo')->result();
        $this->load->view('tela_principal'); 
       $this->load->view('cadastros_cargos/gera_pdf_cargos',$data); 			
		}
}