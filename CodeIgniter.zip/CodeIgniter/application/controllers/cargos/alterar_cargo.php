<?php
 
class Alterar_cargo extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "alterar")
$this->alterar(); 
else $this->index();

}  
    function alterar() {

$this->load->model('cadastra_cargo_model', 'model', TRUE);
           // echo $_POST['nome']; 
             //  $nome= $_POST['nome'];
		$data['cargo_func'] = $this->input->post('nome_cargo');
                $data['salario_cargo'] = $this->input->post('salario_cargo');
         
  		/* Carrega o modelo */
		
 		/* Chama a função alterae do modelo */
                 
 $this->model->alterar_cargo($data) ;?>
	<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("Usuario alterado com sucesso!");
         
         window.location="http://localhost/CodeIgniter/index.php/cargos/consultar_cargo/envia_consulta";
</SCRIPT> <?php
}}?>