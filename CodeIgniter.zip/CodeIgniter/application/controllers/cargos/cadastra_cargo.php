<?php

class Cadastra_cargo extends CI_Controller{
   function _remap($method){ 
// chama a função gravar() somente se o método // for "excluir" 
if($method == "cadastrar")
$this->cadastrar(); 
else $this->index();

}  
 
  function cadastrar() {

   echo  $nome_email = $_POST['nome_cargo'];
                $data['matricula_empresa']=$_SESSION["matricula_logada"];
		$data['cargo_func'] = $this->input->post('nome_cargo');
                $data['salario_cargo'] = $this->input->post('salario_cargo');
               
  		/* Carrega o modelo */
		$this->load->model('cadastra_cargo_model', 'model', TRUE);
 		/* Chama a função inserir do modelo */
                
$this->model->cadastrar($data) ;
 ?><SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
         alert ("A operação foi realizada com sucesso!\n\
          "
                 );
         
         window.location="http://localhost/CodeIgniter/index.php/cargos/encaminhaLink_cargo/tela_cadastro_cargo";
</SCRIPT> <?php     }}


